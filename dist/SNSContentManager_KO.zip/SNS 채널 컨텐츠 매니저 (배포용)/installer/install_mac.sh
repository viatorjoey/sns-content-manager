#!/bin/bash
# ─────────────────────────────────────────────────────────────
#  SNS 채널 컨텐츠 매니저 — Mac 설치 (Apple Silicon · Intel 공용)
#  필요한 것: 인터넷 연결. 관리자 권한(sudo) 필요 없음.
# ─────────────────────────────────────────────────────────────
set -uo pipefail
PKG="$(cd "$(dirname "$0")/.." && pwd)"
APPNAME="SNS 채널 컨텐츠 매니저"
LABEL="com.snscm.server"
DATA="$HOME/Library/Application Support/SNSContentManager"
APPDIR="$HOME/Applications/$APPNAME.app"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
OLD="$HOME/Library/Application Support/TikTokLiveRecorder"
UIDN=$(id -u)
LOGS="$HOME/Library/Logs/SNSContentManager"
mkdir -p "$LOGS" "$DATA/bin" "$DATA/data"
LOG="$LOGS/install.log"
exec > >(tee -a "$LOG") 2>&1

step(){ printf "\n\033[1;36m▶ %s\033[0m\n" "$*"; }
fail(){ printf "\n\033[1;31m✖ %s\033[0m\n설치 기록: %s\n" "$*" "$LOG"; osascript -e "display dialog \"설치 중 문제가 생겼어요.\n\n$*\n\n설치 기록: $LOG\" buttons {\"확인\"} with icon stop with title \"$APPNAME\"" >/dev/null 2>&1; exit 1; }

echo "════════ $APPNAME 설치 ($(date)) ════════"

# 1) uv (파이썬·패키지 설치 도구)
step "설치 도구(uv) 준비"
export PATH="$HOME/.local/bin:$PATH"
if ! command -v uv >/dev/null 2>&1; then
  curl -LsSf https://astral.sh/uv/install.sh | sh || fail "uv 설치 실패 (인터넷 연결 확인)"
  export PATH="$HOME/.local/bin:$PATH"
fi
UV="$(command -v uv)" || fail "uv 를 찾지 못했어요"

# 2) 실행 중인 이전 버전 정리 (진행 중인 녹화 파일은 안전하게 마무리)
step "이전 버전 정리"
for port in 8777 8765; do
  curl -s -m 3 -X POST -H 'X-App: tlr' "http://127.0.0.1:$port/api/restart" >/dev/null 2>&1 || true
done
sleep 3
launchctl bootout "gui/$UIDN/$LABEL" 2>/dev/null || true
launchctl bootout "gui/$UIDN/com.viator.tiktoklive" 2>/dev/null || true
rm -f "$HOME/Library/LaunchAgents/com.viator.tiktoklive.plist"
pkill -f "SNSContentManager/app/launcher.py" 2>/dev/null || true
pkill -f "Contents/Resources/window.py" 2>/dev/null || true
for old in "$HOME/Desktop/SNS 채널 컨텐츠 매니저.app" "$HOME/Desktop/SNS 채널 컨텐츠 저장.app" "$HOME/Desktop/TikTok 라이브 녹화.app" \
           "$HOME/Desktop/1_틱톡녹화_설치.command" "$HOME/Desktop/2_틱톡녹화_시작.command"; do
  [ -e "$old" ] && mv "$old" "$HOME/.Trash/$(basename "$old").$(date +%s)" 2>/dev/null && echo "  이전 앱을 휴지통으로 옮김: $(basename "$old")"
done

# 3) 앱 파일 복사
step "앱 파일 복사"
rm -rf "$DATA/app.new"; cp -R "$PKG/app" "$DATA/app.new" || fail "앱 파일 복사 실패"
rm -rf "$DATA/app"; mv "$DATA/app.new" "$DATA/app"
chmod +x "$DATA/app/"*.py

# 4) 파이썬 환경 + 필요한 프로그램
step "파이썬 3.12 환경 만들기"
"$UV" python install 3.12 || fail "파이썬 설치 실패"
if [ ! -x "$DATA/env/bin/python" ]; then
  "$UV" venv "$DATA/env" --python 3.12 || fail "파이썬 환경 만들기 실패"
fi
PY="$DATA/env/bin/python"
step "필요한 프로그램 설치 (yt-dlp · gallery-dl · ffmpeg · 앱 창) — 몇 분 걸려요"
"$UV" pip install -p "$PY" -U -r "$DATA/app/requirements.txt" || fail "프로그램 설치 실패"

# 5) 틱톡 라이브 녹화기
step "틱톡 라이브 녹화기 설치"
TMP=$(mktemp -d)
curl -L --fail -o "$TMP/rec.zip" "https://github.com/Michele0303/tiktok-live-recorder/archive/refs/heads/main.zip" || fail "녹화기 다운로드 실패"
(cd "$TMP" && unzip -q rec.zip) || fail "녹화기 압축 풀기 실패"
SRC=$(ls -d "$TMP"/tiktok-live-recorder-* | head -1)
for f in cookies.json telegram.json; do
  [ -f "$DATA/recorder/src/$f" ] && cp "$DATA/recorder/src/$f" "$SRC/src/$f"
  [ ! -f "$DATA/recorder/src/$f" ] && [ -f "$HOME/tiktok-live-recorder/src/$f" ] && cp "$HOME/tiktok-live-recorder/src/$f" "$SRC/src/$f"
done
rm -rf "$DATA/recorder"; mv "$SRC" "$DATA/recorder"; rm -rf "$TMP"
"$UV" pip install -p "$PY" -r "$DATA/recorder/pyproject.toml" || fail "녹화기 구성요소 설치 실패"

# 6) ffmpeg
step "ffmpeg 준비"
"$PY" - <<'PYEOF' || fail "ffmpeg 준비 실패"
import imageio_ffmpeg, shutil, os, pathlib
d = pathlib.Path(os.path.expanduser("~/Library/Application Support/SNSContentManager/bin"))
d.mkdir(parents=True, exist_ok=True)
t = d / "ffmpeg"
shutil.copy2(imageio_ffmpeg.get_ffmpeg_exe(), t); os.chmod(t, 0o755)
print("  ffmpeg:", t)
PYEOF

# 7) 이전 데이터 옮기기 (녹화 목록·다운로드 기록·설정)
if [ -d "$OLD" ] && [ ! -f "$DATA/data/jobs.json" ] && [ "$(cat "$DATA/app/edition.json" 2>/dev/null | grep -c public)" = "0" ]; then
  step "이전 버전의 목록·기록·설정 옮기기"
  for f in jobs.json settings.json downloads.json live_history.json; do
    [ -f "$OLD/$f" ] && cp "$OLD/$f" "$DATA/data/$f"
  done
  [ -d "$OLD/avatars" ] && cp -R "$OLD/avatars" "$DATA/data/avatars"
  "$PY" - <<'PYEOF'
import json, os, pathlib
p = pathlib.Path(os.path.expanduser("~/Library/Application Support/SNSContentManager/data/settings.json"))
try:
    s = json.loads(p.read_text(encoding="utf-8"))
except Exception:
    s = {}
old_local = os.path.expanduser("~/Downloads/다운로드")
if os.path.isdir(old_local):
    s.setdefault("local", old_local)          # 이전과 같은 폴더를 계속 사용
p.write_text(json.dumps(s, ensure_ascii=False), encoding="utf-8")
PYEOF
fi

# 8) 앱 아이콘 (응용 프로그램 폴더)
step "앱 만들기: ~/Applications/$APPNAME.app"
mkdir -p "$HOME/Applications"
rm -rf "$APPDIR"
mkdir -p "$APPDIR/Contents/MacOS" "$APPDIR/Contents/Resources"
cp "$DATA/app/icon.icns" "$APPDIR/Contents/Resources/AppIcon.icns"
cat > "$APPDIR/Contents/Info.plist" <<PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>run</string>
<key>CFBundleIdentifier</key><string>com.snscm.app</string>
<key>CFBundleName</key><string>$APPNAME</string>
<key>CFBundleDisplayName</key><string>$APPNAME</string>
<key>CFBundleIconFile</key><string>AppIcon</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>$(cat "$DATA/app/VERSION")</string>
<key>LSMinimumSystemVersion</key><string>11.0</string>
<key>NSHighResolutionCapable</key><true/>
</dict></plist>
PLISTEOF
cat > "$APPDIR/Contents/MacOS/run" <<'RUNEOF'
#!/bin/bash
D="$HOME/Library/Application Support/SNSContentManager"
exec "$D/env/bin/python" "$D/app/launcher.py" >>"$HOME/Library/Logs/SNSContentManager/window.log" 2>&1
RUNEOF
chmod +x "$APPDIR/Contents/MacOS/run"
touch "$APPDIR"
# Launchpad·Spotlight 에 바로 보이도록 등록
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "$APPDIR" >/dev/null 2>&1 || true

# 9) 백그라운드 서비스 (창을 닫아도·재시동 후에도 녹화·다운로드 계속)
step "백그라운드 서비스 등록"
mkdir -p "$HOME/Library/LaunchAgents"
cat > "$PLIST" <<PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key><array>
    <string>$PY</string>
    <string>$DATA/app/server.py</string>
  </array>
  <key>WorkingDirectory</key><string>$DATA</string>
  <key>EnvironmentVariables</key><dict>
    <key>PATH</key><string>$DATA/bin:$DATA/env/bin:$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin</string>
    <key>PYTHONIOENCODING</key><string>utf-8</string>
  </dict>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ProcessType</key><string>Interactive</string>
  <key>StandardOutPath</key><string>$LOGS/server.log</string>
  <key>StandardErrorPath</key><string>$LOGS/server.log</string>
</dict></plist>
PLISTEOF
launchctl bootstrap "gui/$UIDN" "$PLIST" 2>/dev/null || launchctl kickstart -k "gui/$UIDN/$LABEL" 2>/dev/null || true

for i in $(seq 1 40); do
  curl -s -m 2 http://127.0.0.1:8777/api/ping >/dev/null 2>&1 && break
  sleep 0.5
done

step "설치 완료 — 앱을 엽니다"
echo "  · 앱 위치: ~/Applications/$APPNAME.app  (Launchpad·Spotlight 에서도 찾을 수 있어요)"
echo "  · 처음 열 때 '네트워크 볼륨/다운로드 폴더 접근' 같은 확인 창이 뜨면 '허용'을 눌러 주세요."
open "$APPDIR"
sleep 8
# 처음 여는 순간 macOS 등록이 늦어 창이 안 뜨는 경우가 있어 한 번 더 확인
pgrep -f "SNSContentManager/app/launcher.py" >/dev/null 2>&1 || open "$APPDIR"
osascript -e "display notification \"설치가 끝났어요. Dock에 고정해 두면 편해요.\" with title \"$APPNAME\"" >/dev/null 2>&1 || true
exit 0
