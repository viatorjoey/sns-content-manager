﻿# SNS 채널 컨텐츠 매니저 — Windows 제거 (받아 둔 영상·사진 파일은 지우지 않음)
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$AppName = 'SNS 채널 컨텐츠 매니저'
$Data    = Join-Path $env:LOCALAPPDATA 'SNSContentManager'

$a = Read-Host "$AppName 를(을) 제거할까요? 받아 둔 영상·사진·녹화 파일은 그대로 남아요. (y/N)"
if ($a -notmatch '^[Yy]$') { Write-Host '취소했어요.'; Start-Sleep 2; exit 0 }

try { Invoke-WebRequest -Method Post -Uri 'http://127.0.0.1:8777/api/restart' -Headers @{ 'X-App' = 'tlr' } -Body '{}' -UseBasicParsing -TimeoutSec 3 | Out-Null; Start-Sleep 5 } catch {}
Get-CimInstance Win32_Process -Filter "Name like 'python%'" | Where-Object { $_.CommandLine -like '*SNSContentManager*' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Start-Sleep 1

Remove-Item (Join-Path ([Environment]::GetFolderPath('Desktop')) "$AppName.lnk") -Force
Remove-Item (Join-Path ([Environment]::GetFolderPath('Programs')) $AppName) -Recurse -Force
Remove-Item (Join-Path ([Environment]::GetFolderPath('Startup')) "$AppName (백그라운드).lnk") -Force
Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\SNSContentManager' -Recurse -Force

$b = Read-Host '녹화 목록·다운로드 기록·로그인 정보 같은 앱 데이터도 지울까요? (y/N)'
if ($b -match '^[Yy]$') {
  Set-Location $env:TEMP
  Remove-Item $Data -Recurse -Force
  Write-Host '앱 데이터를 지웠어요.'
} else {
  foreach ($d in 'env', 'app', 'recorder', 'bin', 'webview') { Remove-Item (Join-Path $Data $d) -Recurse -Force }
  Write-Host "목록·기록·설정은 남겨 뒀어요 (다시 설치하면 이어서 사용): $Data\data"
}
Write-Host '제거를 마쳤어요.'
Start-Sleep 3
