#!/bin/bash
# SNS 채널 컨텐츠 매니저 — Mac 제거 (받아 둔 영상·사진 파일은 지우지 않음)
APPNAME="SNS 채널 컨텐츠 매니저"
LABEL="com.snscm.server"
DATA="$HOME/Library/Application Support/SNSContentManager"
UIDN=$(id -u)

echo "$APPNAME 를(을) 제거할까요? 받아 둔 영상·사진·녹화 파일은 그대로 남아요. [y/N]"
read -r ans
[[ "$ans" =~ ^[Yy]$ ]] || { echo "취소했어요."; exit 0; }

curl -s -m 3 -X POST -H 'X-App: tlr' http://127.0.0.1:8777/api/restart >/dev/null 2>&1 || true
sleep 3
launchctl bootout "gui/$UIDN/$LABEL" 2>/dev/null || true
rm -f "$HOME/Library/LaunchAgents/$LABEL.plist"
pkill -f "SNSContentManager/app/" 2>/dev/null || true
mv "$HOME/Applications/$APPNAME.app" "$HOME/.Trash/$APPNAME.app.$(date +%s)" 2>/dev/null || true

echo "녹화 목록·다운로드 기록·로그인 정보 같은 앱 데이터도 지울까요? [y/N]"
read -r ans2
if [[ "$ans2" =~ ^[Yy]$ ]]; then
  rm -rf "$DATA"
  echo "앱 데이터를 지웠어요."
else
  rm -rf "$DATA/env" "$DATA/app" "$DATA/recorder" "$DATA/bin" "$DATA/webview"
  echo "목록·기록·설정은 남겨 뒀어요 (다시 설치하면 이어서 사용): $DATA/data"
fi
echo "제거를 마쳤어요."
