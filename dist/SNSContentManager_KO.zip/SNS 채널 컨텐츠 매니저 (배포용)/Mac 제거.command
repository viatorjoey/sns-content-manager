#!/bin/bash
cd "$(dirname "$0")"
/bin/bash "./installer/uninstall_mac.sh"
echo; read -n 1 -s -r -p "창을 닫으려면 아무 키나 누르세요…"
