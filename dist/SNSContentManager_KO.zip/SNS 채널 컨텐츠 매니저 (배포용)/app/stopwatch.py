"""녹화기 공용: '중지' 신호를 Ctrl+C(KeyboardInterrupt)로 바꿔 주는 도우미.

맥·리눅스: 앱이 보내는 SIGINT 를 그대로 받음.
윈도우: 백그라운드 프로그램끼리는 Ctrl+C 를 보낼 수 없어서, 앱이 '중지 파일'(SNSCM_STOP)을 만들면
        이 도우미가 알아채고 Ctrl+C 와 똑같이 처리한다 → 녹화 파일이 정상적으로 마무리됨.
"""
import os
import signal
import threading
import time
import _thread


def install():
    stop = os.environ.get("SNSCM_STOP")
    if hasattr(signal, "SIGBREAK"):
        signal.signal(signal.SIGBREAK, lambda *a: _thread.interrupt_main())
    try:
        signal.signal(signal.SIGTERM, lambda *a: _thread.interrupt_main())
    except Exception:
        pass
    if not stop:
        return

    def watch():
        while True:
            if os.path.exists(stop):
                try:
                    os.remove(stop)
                except Exception:
                    pass
                _thread.interrupt_main()
                time.sleep(5)       # 두 번째 신호가 필요할 때(마무리 중 멈춤 등)를 위해 계속 감시
            time.sleep(1)

    threading.Thread(target=watch, daemon=True).start()


def stop_requested():
    stop = os.environ.get("SNSCM_STOP")
    return bool(stop) and os.path.exists(stop)
