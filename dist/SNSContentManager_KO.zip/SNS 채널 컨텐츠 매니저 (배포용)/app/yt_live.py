#!/usr/bin/env python3
"""유튜브 라이브 녹화기 (SNS 채널 컨텐츠 매니저)

틱톡·인스타 녹화기와 같은 사용법:
  yt_live.py -user 핸들 -mode automatic|manual [-automatic_interval 분] -output 폴더
  yt_live.py -user 핸들 --check     → 방송 중/예정인지 JSON 한 줄로 출력

yt-dlp 로 https://www.youtube.com/@핸들/live 를 확인·녹화한다.
예정된 라이브(예약 방송)가 있으면 시작 시각까지 기다렸다가 바로 녹화한다.
"""
import argparse
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import urllib.request
from datetime import datetime
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import stopwatch  # noqa: E402

IS_WIN = sys.platform.startswith("win")
NEWGRP = 0x00000200 if IS_WIN else 0
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/130.0 Safari/537.36")


def log(*a):
    print(*a, flush=True)


def ytdlp():
    d = Path(sys.executable).parent                          # 앱 전용 환경의 최신 yt-dlp
    for c in (d / "yt-dlp.exe", d / "yt-dlp", d / "Scripts" / "yt-dlp.exe"):
        if c.exists():
            return str(c)
    return shutil.which("yt-dlp") or "yt-dlp"


def live_url(user):
    return f"https://www.youtube.com/@{user}/live"


def probe(user):
    """{'status': is_live|is_upcoming|not_live, 'viewers', 'title', 'start'(예정 시각 ISO)}"""
    try:
        r = subprocess.run([ytdlp(), "--skip-download", "--no-warnings", "--ignore-no-formats-error",
                            "--print", "%(live_status)s\t%(concurrent_view_count|0)s\t%(release_timestamp|)s\t%(title)s",
                            live_url(user)], capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=60, creationflags=0x08000000 if IS_WIN else 0)
    except Exception as e:
        return {"status": None, "error": str(e)}
    line = (r.stdout or "").strip().splitlines()
    if not line:
        err = (r.stderr or "").strip().splitlines()[-1:] or [""]
        # 라이브가 없으면 yt-dlp 가 오류로 끝남 → 방송 안 함
        if re.search(r"not currently live|does not exist|no video|Unable to recognize", err[0], re.I) or r.returncode:
            return {"status": "not_live"}
        return {"status": None, "error": err[0]}
    st, viewers, ts, title = (line[-1].split("\t") + ["", "", "", ""])[:4]
    start = ""
    if ts and ts.isdigit():
        start = datetime.fromtimestamp(int(ts)).isoformat(timespec="minutes")
    return {"status": st, "viewers": int(viewers) if viewers.isdigit() else 0, "title": title, "start": start}


def avatar(user):
    try:
        req = urllib.request.Request(f"https://www.youtube.com/@{user}", headers={"User-Agent": UA, "Accept-Language": "ko,en"})
        with urllib.request.urlopen(req, timeout=10) as r:
            html = r.read(400000).decode("utf-8", "replace")
        m = re.search(r'<meta property="og:image" content="([^"]+)"', html)
        return m.group(1) if m else ""
    except Exception:
        return ""


def record(user, out: Path, wait):
    out.mkdir(parents=True, exist_ok=True)
    tmpl = str(out / f"YT_{user}_{datetime.now():%Y%m%d_%H%M%S}.%(ext)s")
    cmd = [ytdlp(), "--no-part", "--no-progress", "-f", "b[protocol*=m3u8]/bv*+ba/b",
           "-S", "vcodec:h264,res,acodec:m4a", "--merge-output-format", "mp4", "--hls-use-mpegts",
           "-o", tmpl, live_url(user)]
    if wait:   # 예정된 방송이면 시작할 때까지 1분 간격으로 기다렸다가 녹화
        cmd[1:1] = ["--wait-for-video", "60"]
    log(f"[*] Recording @{user}")
    p = subprocess.Popen(cmd, creationflags=NEWGRP)
    try:
        rc = p.wait()
    except KeyboardInterrupt:      # 앱의 '중지' → yt-dlp 에도 중지 신호를 보내 파일을 마무리
        if IS_WIN:
            try:
                os.kill(p.pid, signal.CTRL_BREAK_EVENT)   # 같은 콘솔을 쓰는 하위 프로그램에 전달됨
            except Exception:
                pass
        try:
            p.wait(timeout=25)
        except Exception:
            p.terminate()
        raise
    log(f"[*] Recording finished (exit {rc})")
    return rc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-user", required=True)
    ap.add_argument("-mode", default="manual")
    ap.add_argument("-automatic_interval", type=int, default=5)
    ap.add_argument("-output", default=".")
    ap.add_argument("-no-update-check", action="store_true")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    user = a.user.lstrip("@")

    if a.check:
        pr = probe(user)
        st = pr.get("status")
        print(json.dumps({"live": None if st is None else st == "is_live",
                          "upcoming": pr.get("start") if st == "is_upcoming" else "",
                          "viewers": pr.get("viewers", 0), "title": pr.get("title", ""),
                          "avatar": avatar(user), "error": pr.get("error", "")}, ensure_ascii=False))
        return 0

    out = Path(a.output)
    try:
        log(f"[*] YouTube @{user} 확인 시작 · 모드 {a.mode}")
        while True:
            pr = probe(user)
            st = pr.get("status")
            if st in ("is_live", "is_upcoming"):
                if st == "is_upcoming":
                    log(f"[*] 예정된 라이브 {pr.get('start') or ''} · 시작되면 바로 녹화")
                record(user, out, wait=(st == "is_upcoming"))
                if a.mode != "automatic":
                    return 0
                time.sleep(15)
                continue
            if a.mode != "automatic":
                log(f"[!] @{user} is not live (지금 방송 중이 아니에요)")
                return 1
            log(f"[*] @{user} is offline · {a.automatic_interval}분 뒤 다시 확인")
            time.sleep(max(1, a.automatic_interval) * 60)
    except KeyboardInterrupt:
        log("[*] stopped by user")
        return 0


if __name__ == "__main__":
    stopwatch.install()
    sys.exit(main())
