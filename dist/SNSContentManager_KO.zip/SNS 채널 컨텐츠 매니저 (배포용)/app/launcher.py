#!/usr/bin/env python3
"""SNS 채널 컨텐츠 매니저 — 앱 창 (맥·윈도우 공용, pywebview)

- 창은 하나만: 이미 열려 있으면 그 창을 앞으로 가져오고 새로 띄우지 않음
- 창을 바로 띄우고(로딩 화면), 백그라운드 서버가 꺼져 있으면 켠 뒤 화면을 불러옴
- 로그인 창(인스타·틱톡·X·스레드)에서 로그인하면 로그인 정보를 쿠키 파일로 저장 → 다운로드·녹화에 사용
- 창을 닫아도 녹화·다운로드(백그라운드 서버)는 계속됨
"""
import json
import os
import socket
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
from email.utils import parsedate_to_datetime
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))
IS_WIN = sys.platform.startswith("win")
IS_MAC = sys.platform == "darwin"
TITLE = "SNS 채널 컨텐츠 매니저"
PORT = int(os.environ.get("TLR_PORT", "8777"))
URL = f"http://127.0.0.1:{PORT}/"
SINGLE_PORT = PORT + 1          # 한 번만 실행되게 하는 신호용 포트
LABEL = "com.snscm.server"


def data_dir():
    if os.environ.get("SNSCM_DATA"):
        return Path(os.environ["SNSCM_DATA"])
    if IS_WIN:
        return Path(os.environ.get("LOCALAPPDATA", Path.home())) / "SNSContentManager"
    if IS_MAC:
        return Path.home() / "Library" / "Application Support" / "SNSContentManager"
    return Path.home() / ".local" / "share" / "SNSContentManager"


DATA = data_dir()
COOKIE_DIR = DATA / "data" / "cookies"
LOG = (Path.home() / "Library" / "Logs" / "SNSContentManager" / "window.log") if IS_MAC else DATA / "logs" / "window.log"
LOG.parent.mkdir(parents=True, exist_ok=True)


def log(*a):
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            print(time.strftime("%m/%d %H:%M:%S"), *a, file=f)
    except Exception:
        pass


try:
    VERSION = (APP_DIR / "VERSION").read_text(encoding="utf-8").strip()
except Exception:
    VERSION = "0"

LOGIN = {
    "instagram": ("인스타그램", "https://www.instagram.com/accounts/login/", ("instagram.com",)),
    "tiktok": ("틱톡", "https://www.tiktok.com/login", ("tiktok.com",)),
    "x": ("X", "https://x.com/i/flow/login", ("x.com", "twitter.com")),
    "threads": ("스레드", "https://www.threads.net/login", ("threads.net", "threads.com", "instagram.com")),
}
POPUP_FIX_JS = r"""(function(){
  if (window.__snscmPopupFix) return; window.__snscmPopupFix = true;
  window.open = function(u){ if (u) { try { location.href = new URL(u, location.href).href; } catch(e) {} } return window; };
  document.addEventListener('click', function(e){
    var a = e.target && e.target.closest ? e.target.closest('a[target]') : null;
    if (a && a.target && a.target !== '_self') a.target = '_self';
  }, true);
})();"""
# 앱 창은 '내장 브라우저'라서 페이스북·구글이 로그인을 막음 → 일반 브라우저와 같은 이름으로 접속
MAC_UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
          "(KHTML, like Gecko) Version/18.0 Safari/605.1.15")
# 이 쿠키가 있어야 '로그인됨' (서버의 LOGIN_COOKIE 와 같은 기준)
LOGIN_KEY = {"instagram": ("sessionid",), "tiktok": ("sessionid", "sessionid_ss"),
             "x": ("auth_token",), "threads": ("sessionid",)}


# ───────────────────────── 한 번만 실행 ─────────────────────────
def other_instance_running():
    """이미 창이 떠 있으면 '보여줘' 신호를 보내고 True"""
    try:
        with socket.create_connection(("127.0.0.1", SINGLE_PORT), timeout=1.5) as s:
            s.sendall(b"show")
        return True
    except Exception:
        return False


def single_listener(on_show):
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.bind(("127.0.0.1", SINGLE_PORT))
    srv.listen(5)

    def loop():
        while True:
            try:
                c, _ = srv.accept()
                c.recv(16)
                c.close()
                on_show()
            except Exception:
                time.sleep(0.5)
    threading.Thread(target=loop, daemon=True).start()
    return srv


# ───────────────────────── 백그라운드 서버 ─────────────────────────
def ping():
    try:
        with urllib.request.urlopen(URL + "api/ping", timeout=2) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return None


def post(path):
    try:
        req = urllib.request.Request(URL + path, data=b"{}", method="POST",
                                     headers={"X-App": "tlr", "Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=3).read()
    except Exception:
        pass


def start_server():
    py = sys.executable
    if IS_WIN:
        pyw = Path(py).with_name("pythonw.exe")
        py = str(pyw) if pyw.exists() else py
        flags = 0x00000008 | 0x00000200 | 0x08000000      # 분리 실행 · 새 그룹 · 창 없음
        subprocess.Popen([py, str(APP_DIR / "server.py")], cwd=str(DATA), creationflags=flags,
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         close_fds=True)
        return
    if IS_MAC:
        uid = os.getuid()
        plist = Path.home() / "Library" / "LaunchAgents" / f"{LABEL}.plist"
        if plist.exists():
            r = subprocess.run(["launchctl", "print", f"gui/{uid}/{LABEL}"], capture_output=True)
            if r.returncode != 0:
                subprocess.run(["launchctl", "bootstrap", f"gui/{uid}", str(plist)], capture_output=True)
            subprocess.run(["launchctl", "kickstart", f"gui/{uid}/{LABEL}"], capture_output=True)
            return
    subprocess.Popen([py, str(APP_DIR / "server.py")], cwd=str(DATA), start_new_session=True,
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def ensure_server(window):
    """서버가 없으면 켜고, 앱이 업데이트됐으면 작업 상태를 유지한 채 새 버전으로 재시작"""
    try:
        p = ping()
        if p and str(p.get("version", "")) != VERSION:
            log("서버 버전이 달라 재시작", p.get("version"), "→", VERSION)
            post("api/restart")
            for _ in range(40):
                time.sleep(0.5)
                if not ping():
                    break
            p = None
        if not p:
            start_server()
            for i in range(80):
                time.sleep(0.5)
                p = ping()
                if p:
                    break
                if i == 20:
                    start_server()          # 한 번 더 시도
        if p:
            window.load_url(URL)
        else:
            window.load_html(ERROR_HTML)
    except Exception:
        log(traceback.format_exc())
        window.load_html(ERROR_HTML)


LOADING_HTML = """<html><body style="margin:0;background:#0f0f13;color:#9a9aab;font:15px -apple-system,'Segoe UI',
'Apple SD Gothic Neo','Malgun Gothic',sans-serif;display:grid;place-items:center;height:100vh">
<div style="text-align:center"><div style="width:46px;height:46px;margin:0 auto 14px;border-radius:13px;
background:linear-gradient(135deg,#25f4ee,#ff3b4f);display:grid;place-items:center">
<i style="width:17px;height:17px;border-radius:50%;background:#fff;display:block;box-shadow:0 0 0 5px rgba(255,255,255,.25)"></i>
</div>SNS 채널 컨텐츠 매니저를 여는 중…</div></body></html>"""
ERROR_HTML = LOADING_HTML.replace("SNS 채널 컨텐츠 매니저를 여는 중…",
                                  "백그라운드 서버를 시작하지 못했어요.<br>앱을 다시 열어 보고, 계속 안 되면 다시 설치해 주세요.")


# ───────────────────────── 로그인 → 쿠키 파일 ─────────────────────────
def morsels(cookies):
    """pywebview get_cookies() 결과(SimpleCookie 목록) → (이름, Morsel)"""
    for c in cookies or []:
        try:
            for name, m in c.items():
                yield name, m
        except Exception:
            continue


def mac_cookie_list(timeout=6):
    """맥: WebKit 쿠키 저장소에서 직접 읽기 (메인 스레드를 막지 않음, 시간 제한 있음).
    pywebview 의 get_cookies 는 창 닫기 이벤트(메인 스레드)에서 부르면 앱 전체가 멈춰서 쓰지 않음."""
    import WebKit
    from PyObjCTools import AppHelper
    out, ev = [], threading.Event()

    def handler(cookies):
        try:
            for c in cookies or []:
                try:
                    exp = c.expiresDate()
                    out.append({"name": str(c.name()), "value": str(c.value()), "domain": str(c.domain()),
                                "path": str(c.path() or "/"), "secure": bool(c.isSecure()),
                                "httponly": bool(c.isHTTPOnly()),
                                "expires": int(exp.timeIntervalSince1970()) if exp is not None else None})
                except Exception:
                    continue
        finally:
            ev.set()

    def ask():
        try:
            WebKit.WKWebsiteDataStore.defaultDataStore().httpCookieStore().getAllCookies_(handler)
        except Exception:
            log("쿠키 읽기 실패", traceback.format_exc())
            ev.set()

    AppHelper.callAfter(ask)
    if not ev.wait(timeout):
        log("쿠키 읽기 시간 초과")
    return list(out)


def generic_cookie_list(w, timeout=6):
    """윈도우 등: pywebview get_cookies 를 별도 스레드에서 시간 제한을 두고 호출"""
    box = {}

    def run():
        try:
            box["v"] = w.get_cookies()
        except Exception:
            box["e"] = traceback.format_exc()
    t = threading.Thread(target=run, daemon=True)
    t.start()
    t.join(timeout)
    out = []
    for name, m in morsels(box.get("v")):
        exp = m.get("expires") or ""
        try:
            ts = int(float(exp)) if str(exp).replace(".", "").isdigit() else int(parsedate_to_datetime(exp).timestamp())
        except Exception:
            ts = None
        out.append({"name": name, "value": m.value, "domain": (m.get("domain") or "").strip(),
                    "path": m.get("path") or "/", "secure": bool(m.get("secure")),
                    "httponly": bool(m.get("httponly")), "expires": ts})
    return out


def cookie_list(w):
    return mac_cookie_list() if IS_MAC else generic_cookie_list(w)


def to_netscape_list(items, domains):
    lines = ["# Netscape HTTP Cookie File", "# SNS 채널 컨텐츠 매니저가 저장한 로그인 정보", ""]
    n = 0
    for c in items:
        dom = c.get("domain") or ""
        if not dom or not any(d in dom for d in domains):
            continue
        ts = c.get("expires") or int(time.time()) + 30 * 86400
        flag = "TRUE" if dom.startswith(".") else "FALSE"
        dom_out = ("#HttpOnly_" + dom) if c.get("httponly") else dom
        lines.append("\t".join([dom_out, flag, c.get("path") or "/", "TRUE" if c.get("secure") else "FALSE",
                                str(int(ts)), c["name"], c["value"]]))
        n += 1
    return "\n".join(lines) + "\n", n


def to_netscape(cookies, domains):
    lines = ["# Netscape HTTP Cookie File", "# SNS 채널 컨텐츠 매니저가 저장한 로그인 정보", ""]
    n = 0
    for name, m in morsels(cookies):
        dom = (m.get("domain") or "").strip()
        if not dom or not any(d in dom for d in domains):
            continue
        exp = m.get("expires") or ""
        try:
            ts = int(float(exp)) if str(exp).replace(".", "").isdigit() else int(parsedate_to_datetime(exp).timestamp())
        except Exception:
            ts = int(time.time()) + 30 * 86400
        secure = "TRUE" if m.get("secure") else "FALSE"
        flag = "TRUE" if dom.startswith(".") else "FALSE"
        if m.get("httponly"):
            dom_out = "#HttpOnly_" + dom
        else:
            dom_out = dom
        lines.append("\t".join([dom_out, flag, m.get("path") or "/", secure, str(ts), name, m.value]))
        n += 1
    return "\n".join(lines) + "\n", n


class Api:
    def __init__(self):
        self.window = None
        self.login_windows = {}

    # 화면에서 부르는 기능 ---------------------------------------------------
    def login(self, site):
        import webview
        if site not in LOGIN:
            return {"ok": False}
        name, url, domains = LOGIN[site]
        w = self.login_windows.get(site)
        if w:
            try:
                w.show()
                return {"ok": True}
            except Exception:
                pass
        w = webview.create_window(f"{name} 로그인 — 로그인을 마치면 이 창을 닫아 주세요", url, width=520, height=780)
        self.login_windows[site] = w
        done = threading.Event()
        keys = LOGIN_KEY.get(site, ())
        lock = threading.Lock()

        def save():
            # 로그인 쿠키가 생겼을 때만 저장 (로그인 전 쿠키로 기존 로그인 정보를 덮어쓰지 않도록)
            if not lock.acquire(blocking=False):
                return 0
            try:
                items = cookie_list(w)
                mine = [c for c in items if any(d in (c.get("domain") or "") for d in domains)]
                if not any(c["name"] in keys and c.get("value") for c in mine):
                    return 0
                text, n = to_netscape_list(mine, domains)
                COOKIE_DIR.mkdir(parents=True, exist_ok=True)
                (COOKIE_DIR / f"{site}.txt").write_text(text, encoding="utf-8")
                return n
            except Exception:
                log("쿠키 저장 실패", site, traceback.format_exc())
                return 0
            finally:
                lock.release()

        def poll():
            time.sleep(4)
            while not done.is_set():
                if save():
                    log("로그인 정보 저장", site)
                done.wait(3)

        def closing():
            # 창 닫기는 메인 스레드에서 불리므로 여기서는 아무것도 기다리지 않음 (멈춤 방지)
            done.set()
            self.login_windows.pop(site, None)
            if IS_MAC:      # 맥은 창이 닫혀도 쿠키 저장소가 남아 있어 마지막으로 한 번 더 저장
                threading.Thread(target=save, daemon=True).start()

        def loaded():
            # 'Facebook으로 로그인' 같은 버튼은 새 창(팝업)을 열려고 해서 앱 창에서는 아무 반응이 없거나
            # 사파리로 튕겨 나감 → 같은 로그인 창 안에서 이어지도록 바꿈
            try:
                w.evaluate_js(POPUP_FIX_JS)
            except Exception:
                pass

        w.events.closing += closing
        w.events.loaded += loaded
        threading.Thread(target=poll, daemon=True).start()
        return {"ok": True}

    def import_cookies(self, site):
        """브라우저 확장 프로그램으로 내보낸 cookies.txt 를 불러오기 (로그인 창이 막힐 때 대안)"""
        import webview
        try:
            r = self.window.create_file_dialog(webview.OPEN_DIALOG, allow_multiple=False,
                                               file_types=("쿠키 파일 (*.txt)", "모든 파일 (*.*)"))
            if not r:
                return {"ok": False}
            src = Path(r[0] if isinstance(r, (list, tuple)) else r)
            text = src.read_text(encoding="utf-8", errors="replace")
            if "\t" not in text:
                return {"ok": False, "error": "Netscape 형식(cookies.txt) 파일이 아니에요"}
            COOKIE_DIR.mkdir(parents=True, exist_ok=True)
            (COOKIE_DIR / f"{site}.txt").write_text(text, encoding="utf-8")
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def logout(self, site):
        try:
            (COOKIE_DIR / f"{site}.txt").unlink()
        except Exception:
            pass
        return {"ok": True}

    def choose_folder(self):
        import webview
        try:
            r = self.window.create_file_dialog(webview.FOLDER_DIALOG)
            return (r[0] if isinstance(r, (list, tuple)) else r) or ""
        except Exception:
            return ""

    def close(self):
        """창만 닫기 (녹화·다운로드는 계속)"""
        try:
            for w in list(self.login_windows.values()):
                w.destroy()
            self.window.destroy()
        except Exception:
            os._exit(0)

    def version(self):
        return VERSION


# ───────────────────────── 창 ─────────────────────────
def set_mac_name():
    try:
        from Foundation import NSBundle
        info = NSBundle.mainBundle().infoDictionary()
        if info is not None:
            info["CFBundleName"] = TITLE
    except Exception:
        pass


def set_icons(window):
    if IS_MAC:
        try:
            from AppKit import NSApplication, NSImage
            from PyObjCTools import AppHelper
            img = NSImage.alloc().initWithContentsOfFile_(str(APP_DIR / "icon.icns"))
            AppHelper.callAfter(lambda: NSApplication.sharedApplication().setApplicationIconImage_(img))
        except Exception:
            pass
    elif IS_WIN:
        try:
            import clr  # noqa (pythonnet — pywebview 와 함께 설치됨)
            from System.Drawing import Icon
            from System import Action
            ico = Icon(str(APP_DIR / "icon.ico"))
            form = window.native
            form.Invoke(Action(lambda: setattr(form, "Icon", ico)))
        except Exception:
            log("아이콘 설정 실패", traceback.format_exc())


def main():
    if other_instance_running():
        return            # 이미 열려 있는 창을 앞으로 가져옴
    if IS_WIN:
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("SNSContentManager.App")
        except Exception:
            pass
    if IS_MAC:
        set_mac_name()
    import webview

    api = Api()
    window = webview.create_window(TITLE, html=LOADING_HTML, width=900, height=940, min_size=(560, 520),
                                   js_api=api, background_color="#0f0f13", text_select=True)
    api.window = window

    def show():
        try:
            window.restore()
        except Exception:
            pass
        try:
            window.show()
            window.on_top = True
            window.on_top = False
        except Exception:
            pass

    try:
        single_listener(show)
    except OSError:
        if other_instance_running():
            return

    def started():
        set_icons(window)
        ensure_server(window)

    storage = DATA / "webview"
    storage.mkdir(parents=True, exist_ok=True)
    ua = {"user_agent": MAC_UA} if IS_MAC else {}
    try:
        webview.start(started, private_mode=False, storage_path=str(storage), icon=str(APP_DIR / "icon.png"), **ua)
    except TypeError:     # 예전 pywebview 는 icon 옵션이 없음
        webview.start(started, private_mode=False, storage_path=str(storage), **ua)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        log(traceback.format_exc())
        raise
