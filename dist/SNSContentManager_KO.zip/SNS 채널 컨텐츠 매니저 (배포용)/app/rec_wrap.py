"""틱톡 라이브 녹화기(tiktok-live-recorder)를 앱에서 실행하기 위한 얇은 포장.

  python rec_wrap.py <recorder>/src/main.py -user 계정 -mode automatic ...

- 윈도우에서도 '중지' 버튼이 Ctrl+C 처럼 동작하도록 stopwatch 를 설치한 뒤
- 녹화기의 main.py 를 그대로 실행한다 (__main__ 으로).
"""
import os
import runpy
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import stopwatch  # noqa: E402

if __name__ == "__main__":
    stopwatch.install()
    main_py = os.path.abspath(sys.argv[1])
    src = os.path.dirname(main_py)
    sys.argv = [main_py] + sys.argv[2:]
    sys.path.insert(0, src)
    os.chdir(os.path.dirname(src))
    runpy.run_path(main_py, run_name="__main__")
