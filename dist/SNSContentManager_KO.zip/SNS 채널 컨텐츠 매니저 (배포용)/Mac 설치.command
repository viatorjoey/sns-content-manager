#!/bin/bash
# 더블클릭하면 SNS 채널 컨텐츠 매니저를 설치합니다.
cd "$(dirname "$0")"
xattr -dr com.apple.quarantine . 2>/dev/null
/bin/bash "./installer/install_mac.sh"
echo; read -n 1 -s -r -p "설치 창을 닫으려면 아무 키나 누르세요…"
