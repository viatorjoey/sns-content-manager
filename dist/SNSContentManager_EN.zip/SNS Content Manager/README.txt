﻿SNS Content Manager 1.2.1
════════════════════════════════════════════════════

Automatically records TikTok, Instagram and YouTube lives, and downloads videos and photos
from TikTok, Instagram, YouTube, X and Threads, organized by creator. Works the same on Mac and Windows.


■ Install (internet required · no admin rights · 5–10 minutes)

  [Mac]  (macOS 11 or later, Apple Silicon or Intel)
    1. Double-click "Install for Mac.command".
       - If you see "unidentified developer": right-click the file → Open → Open again.
    2. Installation runs in a Terminal window. The app opens when it is done.
    3. App location: Home folder › Applications › SNS Content Manager
       (also in Launchpad and Spotlight — keep it in the Dock for quick access.)

  [Windows]  (Windows 10 / 11)
    1. Extract the zip first (do not run it from inside the zip).
    2. Double-click "Install for Windows.bat".
       - If "Windows protected your PC" appears: More info → Run anyway
    3. Installation runs in a blue window. The app opens when it is done.
    4. An "SNS Content Manager" icon is added to the Desktop and Start menu.

  What gets installed: Python 3.12 (app-only), yt-dlp, gallery-dl, ffmpeg, TikTok live recorder,
  and the app window component (Edge WebView2 on Windows). Everything stays inside your user folder.


■ Features

  🔴 Live recording (TikTok · Instagram · YouTube)
    - Auto watch: records automatically when a live starts, then keeps watching
    - Record now / Scheduled (start time · duration) / 🧠 Regular schedule (learns past start times)
    - LIVE badge · notification when a live starts · 👀 Watch · 👤 Profile · 📁 Folder buttons
    - Scheduled YouTube lives show the "⏰ Upcoming" time and are recorded the moment they start

  ⬇️ Video & photo download (TikTok · Instagram · YouTube · X · Threads)
    - 📋 Clipboard auto-download: just copy a link
        live link → live recording / post link → download / profile link → the whole account
    - Whole YouTube channels/playlists are only added to the list → click "▶ Start download"
    - X broadcasts and Spaces are recorded until they end
    - Posts you already have are skipped; only new posts are downloaded

  📱 Send from iPhone
    - In the app, Download tab › "📱 iPhone connection" → turn it on and scan the QR code with your
      iPhone camera. A phone page opens where you can send links and follow progress.
      (Safari Share → Add to Home Screen)
    - With the iPhone Shortcuts app you can add "Send to SNS Manager" to the Share menu.
      Step-by-step instructions are shown in the app.
    - Works on the same Wi-Fi. To use it anywhere, install Tailscale on the computer and iPhone
      and sign in with the same account.
    - Allow incoming connections when macOS or Windows Firewall asks.
    - The computer and the app must be on.

  📁 Save location: (default) Downloads › SNS Content › creator › Live / Videos / Photos
    File names start with the date, so they sort chronologically. Change the folder under "💾 Save location".

  🔑 Login (Instagram · TikTok · X · Threads)
    - Click "🔑 … login" in the Download tab to open a login window inside the app. Log in, then close it.
    - Logins are stored only on your computer. Using a secondary account is recommended.

  ⚙️ Other
    - Recording and downloads keep running in the background after you close the window
      (and start automatically when the computer starts). Use ⏹ Stop or "⏹ Stop all" to stop them.
    - yt-dlp, gallery-dl, ffmpeg and the recorder update themselves once a day.
    - The computer will not sleep while recording. (Laptops may stop when the lid is closed.)


■ Uninstall
  [Mac]      Double-click "Uninstall for Mac.command"
  [Windows]  Double-click "Uninstall for Windows.bat", or Settings › Apps › SNS Content Manager › Uninstall
  Your downloaded videos, photos and recordings are not deleted.


■ Troubleshooting
  Install and app logs are saved here. Please include them when reporting a problem.
    Mac:      ~/Library/Logs/SNSContentManager
    Windows:  %LOCALAPPDATA%\SNSContentManager\logs


■ Please read
  - Other people's videos, photos and streams are protected by copyright and portrait rights.
    Use downloaded content for personal archiving and reference only, and get the creator's
    permission before re-uploading or using it commercially.
  - Follow each platform's terms of service. This is an unofficial tool not affiliated with
    TikTok, Instagram, YouTube, X or Threads; some features may stop working when platforms change.
  - Open-source components: yt-dlp (Unlicense), gallery-dl (GPL-2.0), FFmpeg (LGPL/GPL),
    tiktok-live-recorder (MIT), pywebview (BSD) — downloaded from their official sources during install.
