"""Thin wrapper to run tiktok-live-recorder from the app.

  python rec_wrap.py <recorder>/src/main.py -user NAME -mode automatic ...

- installs stopwatch so Stop works like Ctrl+C on Windows too
- then runs the recorder main.py as __main__.
"""
import os
import runpy
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import stopwatch  # noqa: E402

if __name__ == "__main__":
    stopwatch.install()
    main_py = os.path.abspath(sys.argv[1])
    src = os.path.dirname(main_py)
    sys.argv = [main_py] + sys.argv[2:]
    sys.path.insert(0, src)
    os.chdir(os.path.dirname(src))
    runpy.run_path(main_py, run_name="__main__")
