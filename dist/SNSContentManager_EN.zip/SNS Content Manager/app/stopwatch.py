"""Recorder helper: turns the app's stop signal into Ctrl+C (KeyboardInterrupt).

Mac/Linux: receives SIGINT from the app.
Windows: background programs cannot send Ctrl+C, so when the app creates the stop file (SNSCM_STOP)
        this helper treats it like Ctrl+C so the file is finalized.
"""
import os
import signal
import threading
import time
import _thread


def install():
    stop = os.environ.get("SNSCM_STOP")
    if hasattr(signal, "SIGBREAK"):
        signal.signal(signal.SIGBREAK, lambda *a: _thread.interrupt_main())
    try:
        signal.signal(signal.SIGTERM, lambda *a: _thread.interrupt_main())
    except Exception:
        pass
    if not stop:
        return

    def watch():
        while True:
            if os.path.exists(stop):
                try:
                    os.remove(stop)
                except Exception:
                    pass
                _thread.interrupt_main()
                time.sleep(5)       # 두 번째 신호가 필요할 때(마무리 중 멈춤 등)를 위해 계속 감시
            time.sleep(1)

    threading.Thread(target=watch, daemon=True).start()


def stop_requested():
    stop = os.environ.get("SNSCM_STOP")
    return bool(stop) and os.path.exists(stop)
