#!/usr/bin/env python3
"""SNS Content Manager - local server (Mac & Windows)"""
import json, os, re, shutil, signal, subprocess, sys, threading, time, uuid
from datetime import datetime, timedelta
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path

IS_WIN = sys.platform.startswith("win")
IS_MAC = sys.platform == "darwin"
HOME = Path.home()
APP_DIR = Path(__file__).resolve().parent


def _default_data():
    if IS_WIN:
        return Path(os.environ.get("LOCALAPPDATA", HOME / "AppData" / "Local")) / "SNSContentManager"
    if IS_MAC:
        return HOME / "Library" / "Application Support" / "SNSContentManager"
    return HOME / ".local" / "share" / "SNSContentManager"


DATA = Path(os.environ.get("SNSCM_DATA", _default_data()))          # 설치 폴더 (env, recorder, bin …)
SUP = Path(os.environ.get("TLR_SUP", DATA / "data"))                 # 목록·설정·기록
LOGDIR = (HOME / "Library" / "Logs" / "SNSContentManager") if IS_MAC else DATA / "logs"   # 맥은 표준 기록 폴더
REC_DIR = Path(os.environ.get("TLR_DIR", DATA / "recorder"))         # 틱톡 녹화기
BIN = DATA / "bin"                                                   # ffmpeg 등
ENV_BIN = Path(sys.executable).parent                                # 앱 전용 파이썬 환경의 실행 파일 폴더
LOGS = SUP / "logs"
JOBS_FILE = SUP / "jobs.json"
PORT = int(os.environ.get("TLR_PORT", "8777"))
PY = os.environ.get("TLR_PY", sys.executable)
HTML_FILE = APP_DIR / "index.html"
try:
    APP_VERSION = (APP_DIR / "VERSION").read_text(encoding="utf-8").strip()
except Exception:
    APP_VERSION = "0"
USER_RE = re.compile(r"^[A-Za-z0-9._]{1,40}$")
ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
SETTINGS_FILE = SUP / "settings.json"
for _p in (SUP, LOGDIR, BIN):
    _p.mkdir(parents=True, exist_ok=True)

# 개인판/배포판 구분 — 배포판(public)은 NAS 기능을 끔
try:
    EDITION = json.loads((APP_DIR / "edition.json").read_text(encoding="utf-8")).get("edition", "personal")
except Exception:
    EDITION = "personal"
NAS_ENABLED = EDITION != "public"

# 다운로드·녹화 파일이 모이는 내 컴퓨터 폴더 (설정에서 바꿀 수 있음)
try:
    _early = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
except Exception:
    _early = {}
DL_OUT = Path(os.environ.get("TLR_DLOUT") or _early.get("local") or (HOME / "Downloads" / "SNS Content"))
OUT = DL_OUT

# 하위 프로그램(yt-dlp·gallery-dl·녹화기)이 ffmpeg 를 찾을 수 있게 PATH 에 추가
os.environ["PATH"] = os.pathsep.join([str(BIN), str(ENV_BIN), os.environ.get("PATH", "")])
os.environ["SNSCM_DATA"] = str(DATA)
os.environ.setdefault("PYTHONIOENCODING", "utf-8")
DL_FILE = SUP / "downloads.json"
URL_RE = re.compile(r"^https?://([a-z0-9-]+\.)*(tiktok\.com|youtube\.com|youtu\.be|instagram\.com|"
                    r"x\.com|twitter\.com|threads\.(net|com)|facebook\.com|fb\.watch|douyin\.com|"
                    r"vimeo\.com|reddit\.com|pinterest\.com|pin\.it)(/\S*)?$", re.I)

for p in (OUT, LOGS, DL_OUT):
    try:
        p.mkdir(parents=True, exist_ok=True)
    except Exception as e:   # 폴더 권한 문제가 있어도 앱 자체는 켜지게
        print("Could not create folder:", p, e, flush=True)

# ───────────────────────── 맥·윈도우 차이 처리 ─────────────────────────
NOWIN = 0x08000000 if IS_WIN else 0          # CREATE_NO_WINDOW
NEWGRP = 0x00000200 if IS_WIN else 0         # CREATE_NEW_PROCESS_GROUP


def spawn(cmd, **kw):
    """Run a child program (no window, stoppable)"""
    if IS_WIN:
        kw["creationflags"] = NOWIN | NEWGRP
    else:
        kw["start_new_session"] = True
    return subprocess.Popen(cmd, **kw)


def run_quiet(cmd, **kw):
    if IS_WIN:
        kw["creationflags"] = NOWIN
    return subprocess.run(cmd, **kw)


def stop_file(key):
    d = SUP / "run"
    d.mkdir(parents=True, exist_ok=True)
    return d / f"{key}.stop"


def soft_stop(p, key=None):
    """Send 'stop' so the recording file is finalized (Mac: Ctrl+C, Windows: stop file)"""
    if p is None or p.poll() is not None:
        return
    if IS_WIN:
        if key:
            try:
                stop_file(key).write_text("stop", encoding="utf-8")
            except Exception:
                pass
    else:
        try:
            os.killpg(p.pid, signal.SIGINT)
        except Exception:
            pass


def hard_stop(p):
    if p is None or p.poll() is not None:
        return
    if IS_WIN:
        run_quiet(["taskkill", "/T", "/F", "/PID", str(p.pid)], capture_output=True)
    else:
        try:
            os.killpg(p.pid, signal.SIGTERM)
        except Exception:
            pass


def open_path(p):
    p = str(p)
    if IS_WIN:
        os.startfile(p)  # noqa
    elif IS_MAC:
        subprocess.Popen(["open", p])
    else:
        subprocess.Popen(["xdg-open", p])


def open_url(u):
    import webbrowser
    webbrowser.open(u)


def reveal(p):
    if IS_WIN:
        subprocess.Popen(["explorer", "/select,", str(p)])
    elif IS_MAC:
        subprocess.Popen(["open", "-R", str(p)])
    else:
        open_path(Path(p).parent)


def clipboard_text():
    try:
        import pyperclip
        return (pyperclip.paste() or "").strip()
    except Exception:
        pass
    if IS_MAC:
        return subprocess.run(["pbpaste"], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=3).stdout.strip()
    return ""


def keep_awake():
    """Keep the computer awake while the app runs"""
    if IS_MAC:
        subprocess.Popen(["caffeinate", "-i", "-w", str(os.getpid())],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    elif IS_WIN:
        try:
            import ctypes
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000001)   # 계속·시스템 깨어있음
        except Exception:
            pass


lock = threading.RLock()
jobs = {}      # id -> dict (저장되는 정보)
procs = {}     # id -> Popen
stopping = set()


def now():
    return datetime.now()


def save():
    with lock:
        data = [{k: v for k, v in j.items()} for j in jobs.values()]
    tmp = JOBS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(JOBS_FILE)


def load():
    if not JOBS_FILE.exists():
        return
    try:
        for j in json.loads(JOBS_FILE.read_text(encoding="utf-8")):
            jobs[j["id"]] = j
    except Exception:
        pass
    # 앱을 다시 켰을 때: 감시 중이던 작업은 다시 시작
    for j in list(jobs.values()):
        if j.get("state") in ("running", "starting"):
            if j["mode"] == "now":          # 'Record now'도 이어서 (방송이 끝났으면 곧 'Done'로 바뀜)
                j["state"] = "idle"
                start_job(j["id"])
            elif j["mode"] == "smart":
                j["state"] = "armed"
            else:
                j["state"] = "idle"
                start_job(j["id"])


def tool_python():
    return sys.executable


PF_PREFIX = {"instagram": "ig", "youtube": "yt"}


def okey(j):
    """Key for live status (separate per platform)"""
    pf = j.get("platform", "tiktok")
    return (PF_PREFIX[pf] + ":" if pf in PF_PREFIX else "") + j["user"]


def resolve_yt_channel(url):
    """YouTube video/live URL → channel @handle"""
    try:
        r = run_quiet([tool("yt-dlp") or "yt-dlp", "--skip-download", "--no-warnings", "--ignore-no-formats-error",
                            "--playlist-items", "1", "--print", "%(uploader_id|)s", url],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=40)
        h = (r.stdout or "").strip().splitlines()
        return h[0].lstrip("@") if h and h[0] else None
    except Exception:
        return None


def log_path(jid):
    return LOGS / f"{jid}.log"


# ── 폴더 정리 규칙: 다운로드/다운로드/<크리에이터>/<라이브|동영상|사진>/<날짜>_... ──
VIDEO_EXT = {"mp4", "mov", "mkv", "webm", "m4v", "flv", "ts", "avi"}
IMAGE_EXT = {"jpg", "jpeg", "png", "webp", "gif", "heic", "avif", "bmp"}
AUDIO_EXT = {"mp3", "m4a", "aac", "opus", "ogg", "wav"}
DATE_PREFIX = re.compile(r"^\d{4}-\d{2}-\d{2}_")


def safe_name(s, fallback="Other"):
    s = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", str(s or "")).strip(" ._")
    return s[:60] or fallback


def ensure_dir(root, *parts):
    """Create folders step by step, reusing existing ones even if NAS stores names differently"""
    import unicodedata
    cur = Path(root)
    for part in parts:
        cand = cur / part
        if not cand.is_dir():
            want = unicodedata.normalize("NFC", part)
            hit = None
            try:
                for c in cur.iterdir():
                    if c.is_dir() and unicodedata.normalize("NFC", c.name) == want:
                        hit = c; break
            except Exception:
                pass
            if hit is None:
                try:
                    cand.mkdir()
                except FileExistsError:
                    pass
                except FileNotFoundError:
                    cur.mkdir(parents=True, exist_ok=True); cand.mkdir(exist_ok=True)
            else:
                cand = hit
        cur = cand
    return cur


def kind_dir(creator, kind, root=None):
    return ensure_dir(root or DL_OUT, safe_name(creator), kind)


def unique_path(p):
    if not p.exists():
        return p
    for i in range(2, 999):
        q = p.with_name(f"{p.stem}_{i}{p.suffix}")
        if not q.exists():
            return q
    return p


def tidy_live():
    """Rename finished live files to 'date_time_Live.mp4'"""
    t = time.time()
    try:
        for d in DL_OUT.glob("*/Live"):
            for f in d.iterdir():
                ext = f.suffix.lower().lstrip(".")
                if not f.is_file() or ext not in ("mp4", "mkv", "mov") or DATE_PREFIX.match(f.name):
                    continue
                if f.name.endswith("_flv.mp4") and t - f.stat().st_mtime < 6 * 3600:   # 녹화기가 변환 중
                    continue
                st = f.stat()
                if t - st.st_mtime < 120:      # 아직 녹화·변환 중일 수 있음
                    continue
                born = getattr(st, "st_birthtime", st.st_mtime)
                new = unique_path(f.with_name(datetime.fromtimestamp(born).strftime("%Y-%m-%d_%H%M") + f"_Live.{ext}"))
                add_history(d.parent.name, datetime.fromtimestamp(born))   # 정기 방송 학습용 기록
                try:
                    f.rename(new)
                except Exception:
                    pass
    except Exception:
        pass


def start_job(jid, interval=None):
    with lock:
        j = jobs[jid]
        if jid in procs and procs[jid].poll() is None:
            return
        mode = "manual" if j["mode"] == "now" else "automatic"
        try:
            outdir = kind_dir(j["user"], "Live")
        except Exception:
            outdir = OUT
        if j.get("platform") in ("instagram", "youtube"):
            script = "ig_live.py" if j["platform"] == "instagram" else "yt_live.py"
            cmd = [tool_python(), str(APP_DIR / script), "-user", j["user"], "-mode", mode,
                   "-output", str(outdir) + os.sep]
        else:
            write_recorder_cookies()
            cmd = [PY, str(APP_DIR / "rec_wrap.py"), str(REC_DIR / "src" / "main.py"), "-user", j["user"], "-mode", mode,
                   "-output", str(outdir) + os.sep, "-no-update-check"]
        if mode == "automatic":
            cmd += ["-automatic_interval", str(interval or j.get("interval", 5))]
        lf = open(log_path(jid), "a", encoding="utf-8")
        lf.write(f"\n== {now():%m/%d %H:%M} start ==\n")
        lf.flush()
        try:
            stop_file(jid).unlink(missing_ok=True)
            env = dict(os.environ, SNSCM_STOP=str(stop_file(jid)), PYTHONUNBUFFERED="1")
            procs[jid] = spawn(cmd, cwd=str(REC_DIR if REC_DIR.exists() else DATA), stdout=lf,
                               stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, env=env)
        except Exception as e:
            lf.write(f"Failed to start: {e}\n")
            j["state"] = "error"
            save()
            return
        j["state"] = "running"
        j["started_at"] = now().isoformat(timespec="seconds")
        if j["mode"] == "schedule" and j.get("duration_min"):
            j["end_at"] = (now() + timedelta(minutes=int(j["duration_min"]))).isoformat(timespec="seconds")
        stopping.discard(jid)
    save()


def stop_job(jid, final_state="stopped", wait=False):
    with lock:
        p = procs.get(jid)
        stopping.add(jid)
        if jid in jobs:
            jobs[jid]["state"] = final_state
    save()
    if not p or p.poll() is not None:
        return

    def _kill():
        soft_stop(p, jid)                 # Ctrl+C 와 같은 신호 → 파일 마무리
        for _ in range(80):
            if p.poll() is not None:
                return
            time.sleep(0.5)
        hard_stop(p)
    if wait:
        _kill()
    else:
        threading.Thread(target=_kill, daemon=True).start()


def last_lines(jid, n=2):
    lp = log_path(jid)
    if not lp.exists():
        return ""
    try:
        with open(lp, "rb") as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - 4000))
            txt = f.read().decode("utf-8", "replace")
    except Exception:
        return ""
    txt = ANSI.sub("", txt).replace("\r", "\n")
    lines = [l.strip() for l in txt.split("\n") if l.strip() and not l.startswith("==")]
    return " / ".join(lines[-n:])[-220:]


def recording_file(user):
    """Recording if a file in the account’s Live folder grew in the last 25 seconds"""
    t = time.time()
    best = None
    try:
        for f in (DL_OUT / safe_name(user) / "Live").iterdir():
            if f.is_file() and t - f.stat().st_mtime < 25:
                best = f
    except Exception:
        pass
    return best


def monitor():
    tick = 0
    while True:
        time.sleep(3)
        tick += 1
        if tick % 10 == 0:
            tidy_live()
        changed = False
        if restarting:
            continue
        with lock:
            for jid, j in list(jobs.items()):
                p = procs.get(jid)
                if j["state"] == "running" and p is not None and p.poll() is not None:
                    if jid in stopping:
                        pass
                    elif j["mode"] == "now":
                        j["state"] = "done" if p.returncode == 0 else "error"
                    elif j["mode"] == "smart":
                        j["state"] = "armed"
                    else:
                        j["state"] = "error"
                    changed = True
                if j["state"] == "scheduled" and j.get("start_at"):
                    try:
                        if now() >= datetime.fromisoformat(j["start_at"]):
                            threading.Thread(target=start_job, args=(jid, 1), daemon=True).start()
                            j["state"] = "starting"
                            changed = True
                    except ValueError:
                        j["state"] = "error"
                if j["state"] == "running" and j.get("end_at") and j["mode"] == "schedule":
                    if now() >= datetime.fromisoformat(j["end_at"]):
                        threading.Thread(target=stop_job, args=(jid, "done"), daemon=True).start()
        if tick % 10 == 0:
            smart_tick()
        if changed:
            save()


# ───────────────────────── 정기 방송 학습 · 자동 예약 ─────────────────────────
HIST_FILE = SUP / "live_history.json"
history = {}          # 계정 -> [방송 시작 시각 ISO, ...]
WD = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
LIVE_NAME = re.compile(r"^(\d{4}-\d{2}-\d{2})_(\d{2})(\d{2})_Live\.")


def load_history():
    global history
    try:
        history = json.loads(HIST_FILE.read_text(encoding="utf-8"))
    except Exception:
        history = {}
    # 이미 녹화해 둔 라이브 파일 이름(날짜_시간_라이브.mp4)에서 지난 방송 시각을 채움
    roots = [DL_OUT] + ([Path(settings["nas"])] if nas_ok else [])
    for root in roots:
        try:
            for f in root.glob("*/Live/*"):
                m = LIVE_NAME.match(f.name)
                if m:
                    add_history(f.parent.parent.name, datetime.fromisoformat(f"{m.group(1)}T{m.group(2)}:{m.group(3)}"), save_=False)
        except Exception:
            pass
    save_history()


def save_history():
    try:
        HIST_FILE.write_text(json.dumps(history, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def add_history(user, dt, save_=True):
    import unicodedata
    user = unicodedata.normalize("NFC", user)
    lst = history.setdefault(user, [])
    # 같은 방송(20분 이내)은 한 번만
    for x in lst:
        try:
            if abs((datetime.fromisoformat(x) - dt).total_seconds()) < 1200:
                return
        except Exception:
            pass
    lst.append(dt.isoformat(timespec="minutes"))
    lst.sort()
    del lst[:-80]
    if save_:
        save_history()


def pattern_of(user):
    """Group start times of the last 8 weeks by weekday and 30 minutes; 2+ repeats = regular slot"""
    from collections import Counter
    import unicodedata
    lst = history.get(unicodedata.normalize("NFC", user), [])
    cut = now() - timedelta(days=56)
    starts = []
    for x in lst:
        try:
            d = datetime.fromisoformat(x)
            if d >= cut:
                starts.append(d)
        except Exception:
            pass
    slot = Counter((d.weekday(), d.hour, 0 if d.minute < 30 else 30) for d in starts)
    by_time = Counter((d.hour, 0 if d.minute < 30 else 30) for d in starts)
    days_at = {}
    for d in starts:
        days_at.setdefault((d.hour, 0 if d.minute < 30 else 30), set()).add(d.weekday())
    slots = []
    for (h, mi), wds in days_at.items():
        if len(wds) >= 4 and by_time[(h, mi)] >= 4:          # 거의 매일 같은 시간
            slots.append({"dow": None, "h": h, "m": mi, "n": by_time[(h, mi)]})
    for (wd, h, mi), n in slot.items():
        if n >= 2 and not any(x["dow"] is None and x["h"] == h and x["m"] == mi for x in slots):
            slots.append({"dow": wd, "h": h, "m": mi, "n": n})
    slots.sort(key=lambda x: (-x["n"], x["dow"] if x["dow"] is not None else -1, x["h"], x["m"]))
    return slots, len(starts)


def next_window(slots):
    """Next expected start, and whether now is inside the window"""
    t = now()
    best = None
    for dd in range(-1, 8):
        day = (t + timedelta(days=dd)).replace(second=0, microsecond=0)
        for sl in slots:
            if sl["dow"] is not None and day.weekday() != sl["dow"]:
                continue
            dt = day.replace(hour=sl["h"], minute=sl["m"])
            if dt + timedelta(minutes=90) < t:
                continue
            if best is None or dt < best:
                best = dt
    if best is None:
        return None, False
    return best, best - timedelta(minutes=10) <= t <= best + timedelta(minutes=90)


def smart_tick():
    """Regular-schedule mode: normal watching while learning, then dense checks in the expected window"""
    for jid, j in list(jobs.items()):
        if j.get("mode") != "smart" or j["state"] not in ("armed", "running"):
            continue
        slots, n = pattern_of(j["user"])
        nxt, in_win = next_window(slots)
        live_now = (onair.get(okey(j)) or {}).get("live") is True
        p = procs.get(jid)
        running = p is not None and p.poll() is None
        should = (not slots) or in_win or live_now
        if should and not running:
            start_job(jid, 1 if (in_win or live_now) else 5)
        elif not should and running and not recording_file(j["user"]):
            stop_job(jid, "armed")


# ───────────────────────── 방송 중인지 확인 ─────────────────────────
onair = {}   # 계정 -> {"live": True/False/None, "viewers": int, "title": str, "at": 시각}


def check_live(user):
    """Check if live from public TikTok info (None = unknown)"""
    import urllib.request
    url = ("https://www.tiktok.com/api-live/user/room/?aid=1988&app_name=tiktok_web"
           f"&device_platform=web_pc&sourceType=54&uniqueId={user}")
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/130.0 Safari/537.36",
        "Referer": f"https://www.tiktok.com/@{user}/live"})
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            data = json.loads(r.read().decode("utf-8", "replace") or "{}")
    except Exception:
        return {"live": None}
    dd = data.get("data") or {}
    room = dd.get("liveRoom") or {}
    st = room.get("status", (dd.get("user") or {}).get("status"))
    if st is None:
        return {"live": None}
    stats = room.get("liveRoomStats") or {}
    u = dd.get("user") or {}
    av = u.get("avatarMedium") or u.get("avatarLarger") or u.get("avatarThumb")
    if av:
        save_avatar(user, av)
    return {"live": st == 2, "viewers": stats.get("userCount") or 0, "title": room.get("title") or ""}


# ───────────────────────── 프로필 사진 · 썸네일 ─────────────────────────
AV_DIR = SUP / "avatars"
TH_DIR = SUP / "thumbs"


def save_avatar(user, url, max_age=86400):
    """Cache profile pictures once a day"""
    import urllib.request
    AV_DIR.mkdir(parents=True, exist_ok=True)
    f = AV_DIR / f"{safe_name(user)}.jpg"
    if f.exists() and time.time() - f.stat().st_mtime < max_age:
        return
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Referer": "https://www.tiktok.com/"})
        with urllib.request.urlopen(req, timeout=10) as r:
            data = r.read()
        if len(data) > 500:
            tmp = f.with_suffix(".tmp"); tmp.write_bytes(data); tmp.replace(f)
    except Exception:
        pass


def ffmpeg_bin():
    return tool("ffmpeg")


_latest_cache = {}


def latest_media(creator):
    """Most recent media in the creator folder (10-minute cache)"""
    if not creator:
        return None
    c = _latest_cache.get(creator)
    if c and time.time() - c[0] < 600 and (c[1] is None or c[1].exists()):
        return c[1]
    best = None
    for kind in ("Photos", "Videos", "Live"):
        try:
            d = creator_folder(creator, kind)
            if d.name != kind:
                continue
            for f in d.iterdir():
                ext = f.suffix.lower().lstrip(".")
                if f.is_file() and (ext in IMAGE_EXT or ext in VIDEO_EXT) and not f.name.startswith("."):
                    if best is None or f.stat().st_mtime > best.stat().st_mtime:
                        best = f
        except Exception:
            pass
        if best is not None and kind == "Photos":
            break                  # 사진이 있으면 사진을 우선 (썸네일 만들기가 빠름)
    _latest_cache[creator] = (time.time(), best)
    return best


def avatar_filler():
    """Slowly cache profile pictures of creators in history"""
    time.sleep(40)
    while True:
        seen = set()
        for d in list(downloads):
            cr = d.get("profile") or ((d.get("files") or [""])[0].split("/")[0] if d.get("files") else "") \
                or creator_from_url(d.get("url", "")) or ""
            if not cr or cr == "Other" or cr in seen:
                continue
            seen.add(cr)
            url = d.get("url", "")
            key = ("ig_" + cr) if "instagram.com" in url else (("yt_" + cr) if ("youtube.com" in url or "youtu.be" in url) else cr)
            f = AV_DIR / f"{safe_name(key)}.jpg"
            if f.exists() and time.time() - f.stat().st_mtime < 7 * 86400:
                continue
            try:
                if "instagram.com" in url:
                    if ig_state():
                        check_live_ig(cr)
                elif "tiktok.com" in url:
                    check_live(cr)
                elif "youtube.com" in url or "youtu.be" in url:
                    check_live_yt(cr)
            except Exception:
                pass
            time.sleep(8)
        time.sleep(3600)


def make_thumb(p):
    """Thumbnails: frame at 1s for videos, resized for photos"""
    import hashlib
    TH_DIR.mkdir(parents=True, exist_ok=True)
    st = p.stat()
    key = hashlib.md5(f"{p}|{st.st_size}|{int(st.st_mtime)}".encode()).hexdigest()
    out = TH_DIR / f"{key}.jpg"
    if out.exists():
        return out
    ff = ffmpeg_bin()
    if not ff:
        return None
    is_vid = p.suffix.lower().lstrip(".") in VIDEO_EXT
    for ss in (["-ss", "1"] if is_vid else []), []:
        try:
            run_quiet([ff, "-y", "-loglevel", "error"] + ss + ["-i", str(p), "-frames:v", "1",
                            "-vf", "scale=240:240:force_original_aspect_ratio=increase,crop=240:240", str(out)],
                           capture_output=True, timeout=20)
        except Exception:
            pass
        if out.exists() and out.stat().st_size > 0:
            return out
    return None


def check_live_ig(user):
    try:
        r = run_quiet([tool_python(), str(Path(__file__).with_name("ig_live.py")), "-user", user, "--check"],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60)
        d = json.loads((r.stdout or "").strip().splitlines()[-1])
    except Exception:
        return {"live": None}
    if d.get("avatar"):
        save_avatar("ig_" + user, d["avatar"])
    return {"live": d.get("live"), "viewers": d.get("viewers") or 0, "title": d.get("title") or "",
            "error": d.get("error", "")}


def check_live_yt(user):
    try:
        r = run_quiet([tool_python(), str(Path(__file__).with_name("yt_live.py")), "-user", user, "--check"],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=90)
        d = json.loads((r.stdout or "").strip().splitlines()[-1])
    except Exception:
        return {"live": None}
    if d.get("avatar"):
        save_avatar("yt_" + user, d["avatar"])
    return {"live": d.get("live"), "viewers": d.get("viewers") or 0, "title": d.get("title") or "",
            "upcoming": d.get("upcoming") or ""}


def live_checker():
    """Check each account once a minute"""
    last = {}
    while True:
        with lock:
            keys = list(dict.fromkeys((okey(j), j["user"], j.get("platform", "tiktok")) for j in jobs.values()))
        for u, name, pf in keys:
            gap = 90 if pf in ("instagram", "youtube") else 60
            if any(jj.get("mode") == "smart" and okey(jj) == u and next_window(pattern_of(name)[0])[1]
                   for jj in list(jobs.values())):
                gap = 30 if pf in ("instagram", "youtube") else 20      # 예상 방송 시간대엔 더 자주
            if time.time() - last.get(u, 0) < gap:
                continue
            r = check_live_ig(name) if pf == "instagram" else (check_live_yt(name) if pf == "youtube" else check_live(name))
            r["at"] = now().strftime("%H:%M")
            prev = onair.get(u, {}).get("live")
            if r.get("live") is True and prev is not True:
                add_history(name, now())
                for jj in list(jobs.values()):     # 정기 방송 자동 계정은 바로 녹화 시작
                    if jj.get("mode") == "smart" and okey(jj) == u and jj["state"] == "armed":
                        threading.Thread(target=start_job, args=(jj["id"], 1), daemon=True).start()
            if r.get("live") is True and prev is not True:   # 방송 시작 → 맥 알림 (소리 포함)
                v = r.get("viewers") or 0
                notify(f"📡 @{name} is live on {({'instagram': 'Instagram', 'youtube': 'YouTube'}).get(pf, 'TikTok')}" + (f" · {v:,} viewers" if v else ""),
                       title="SNS Content Manager · Live started", sound=True)
            if r.get("live") is None and prev is not None:
                r = dict(onair[u], at=r["at"])     # 일시적인 확인 실패는 이전 상태 유지
            onair[u] = r
            last[u] = time.time()
            time.sleep(1.5)
        time.sleep(5)


def state_payload():
    out = []
    with lock:
        for j in jobs.values():
            d = dict(j)
            st = j["state"]
            rec = None
            if st == "running":
                rec = recording_file(j["user"])
            d["recording"] = bool(rec)
            oa = dict(onair.get(okey(j), {"live": None}))
            if rec:
                oa["live"] = True     # 녹화 파일이 커지고 있으면 확실히 방송 중
            d["onair"] = oa
            if j.get("mode") == "smart":
                slots, n = pattern_of(j["user"])
                nxt, in_win = next_window(slots)
                d["pattern"] = [{"dow": (WD[x["dow"]] if x["dow"] is not None else "Daily"), "time": f"{x['h']:02d}:{x['m']:02d}",
                                 "n": x["n"]} for x in slots[:4]]
                d["hist_n"] = n
                d["next"] = nxt.isoformat(timespec="minutes") if nxt else None
                d["in_window"] = in_win
            d["file"] = rec.name if rec else None
            d["log"] = last_lines(j["id"])
            out.append(d)
    out.sort(key=lambda x: x.get("created", ""))
    files = []
    try:
        loc = [f for f in DL_OUT.glob("*/Live/*") if f.is_file() and not f.name.startswith(".")]
        fs = sorted(loc + nas_live_cache, key=lambda f: f.stat().st_mtime if f.exists() else 0, reverse=True)[:12]
        files = [{"name": f"{f.parent.parent.name} › {f.name}", "size": f.stat().st_size,
                  "path": str(f.relative_to(DL_OUT if f in loc else Path(settings["nas"]))),
                  "where": "mac" if f in loc else "nas",
                  "live": time.time() - f.stat().st_mtime < 25,
                  "time": datetime.fromtimestamp(f.stat().st_mtime).strftime("%m/%d %H:%M")} for f in fs]
    except Exception:
        pass
    return {"jobs": out, "files": files, "out": str(OUT), "now": now().isoformat(timespec="seconds"),
            "clip": bool(settings.get("clip")), "live_mode": settings.get("live_mode", "now"),
            "downloads": downloads[:300],
            "ig_login": ig_state(), "tt_login": tt_state(), "logins": login_states(),
            "update": dict(upd),
            "storage": {"nas": settings.get("nas", ""), "nas_url": settings.get("nas_url", ""),
                        "nas_ok": nas_ok, "pending": nas_pending, "local": str(DL_OUT),
                        "last_error": nas_error, "nas_enabled": NAS_ENABLED},
            "remote": {"available": REMOTE_ENABLED, "on": bool(settings.get("remote_on")), "running": remote_srv is not None},
            "edition": EDITION, "platform": "win" if IS_WIN else ("mac" if IS_MAC else "linux"),
            "tools": {"yt-dlp": bool(tool("yt-dlp")), "gallery-dl": bool(tool("gallery-dl"))}}


# ───────────────────────── 클립보드 자동 다운로드 ─────────────────────────
import queue, shutil
settings = {"clip": True,
            "nas": os.environ.get("TLR_NAS", ""),
            "nas_url": ""}
downloads = []          # 최신이 앞
dl_q = queue.Queue()
seen = set()


def load_dl():
    global downloads
    try:
        settings.update(json.loads(SETTINGS_FILE.read_text(encoding="utf-8")))
    except Exception:
        # 처음 실행: 판(edition)에 들어 있는 기본 설정 적용 (개인판의 NAS 경로 등)
        try:
            ed = json.loads((APP_DIR / "edition.json").read_text(encoding="utf-8"))
            settings.update(ed.get("defaults", {}).get("win" if IS_WIN else ("mac" if IS_MAC else "linux"), {}))
        except Exception:
            pass
    try:
        downloads = [x for x in json.loads(DL_FILE.read_text(encoding="utf-8")) if x.get("status") != "live"][:300]
        for d in downloads:         # 받는 중이던 것은 이어서 받기 (사용자가 중단하지 않은 한 계속)
            if d["status"] in ("queued", "downloading"):
                d["status"] = "queued"; d["msg"] = "Resuming…"
                dl_q.put(d["id"])
    except Exception:
        downloads = []


def save_dl():
    try:
        SETTINGS_FILE.write_text(json.dumps(settings), encoding="utf-8")
        DL_FILE.write_text(json.dumps(downloads[:300], ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def notify(msg, title="SNS Content Manager", sound=False):
    m = msg.replace('"', "'").replace("\\", "")
    t = title.replace('"', "'")
    if IS_MAC:
        snd = ' sound name "Glass"' if sound else ""
        subprocess.Popen(["osascript", "-e", f'display notification "{m}" with title "{t}"{snd}'],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    elif IS_WIN:
        # 윈도우 10/11 기본 알림 (추가 설치 없이 PowerShell 로)
        x = lambda v: v.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("'", "&apos;")
        audio = "" if sound else "<audio silent='true'/>"
        ps = ("[Windows.UI.Notifications.ToastNotificationManager,Windows.UI.Notifications,ContentType=WindowsRuntime]>$null;"
              "[Windows.Data.Xml.Dom.XmlDocument,Windows.Data.Xml.Dom.XmlDocument,ContentType=WindowsRuntime]>$null;"
              "$d=New-Object Windows.Data.Xml.Dom.XmlDocument;"
              f"$d.LoadXml('<toast><visual><binding template=\"ToastGeneric\"><text>{x(t)}</text><text>{x(m)}</text></binding></visual>{audio}</toast>');"
              "$a='{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\\WindowsPowerShell\\v1.0\\powershell.exe';"
              "[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($a).Show("
              "[Windows.UI.Notifications.ToastNotification]::new($d))")
        try:
            spawn(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass


RESERVED_IG = {"p", "reel", "reels", "tv", "explore", "stories", "accounts", "direct"}
RESERVED_X = {"i", "home", "search", "hashtag", "explore", "notifications", "messages", "settings"}


def profile_of(url):
    """Username if it is a profile URL, else None"""
    from urllib.parse import urlparse
    try:
        u = urlparse(url)
    except Exception:
        return None
    host = (u.hostname or "").lower()
    segs = [s for s in u.path.split("/") if s]
    if "tiktok.com" in host and len(segs) == 1 and segs[0].startswith("@"):
        return segs[0][1:]
    if "instagram.com" in host and segs and segs[0] not in RESERVED_IG and \
            (len(segs) == 1 or (len(segs) == 2 and segs[1] in ("reels", "tagged", "posts", "saved"))):
        return segs[0]
    if any(h in host for h in ("x.com", "twitter.com")) and (len(segs) == 1 or (len(segs) == 2 and segs[1] == "media")) \
            and segs[0] not in RESERVED_X:
        return segs[0]
    if "youtube.com" in host and segs and segs[0].startswith("@") and (len(segs) == 1 or segs[1] in ("videos", "shorts")):
        return segs[0][1:]
    return None


def enqueue(url):
    url = url.strip()
    if not URL_RE.match(url):
        return None, "Unsupported link (TikTok, YouTube, Instagram, X, …)"
    with lock:
        if any(d["url"] == url and d["status"] in ("queued", "downloading", "paused") for d in downloads):
            return None, "Already in the list"
        prof = profile_of(url)
        # 유튜브 채널 전체는 양이 많아서 목록에만 추가 → 사용자가 '받기 시작'을 눌러야 진행
        # 개별 영상(watch·shorts·youtu.be)은 바로 받고, 채널·재생목록 전체만 대기
        hold = (bool(prof) and bool(re.search(r"youtube\.com|youtu\.be", url))) or "youtube.com/playlist" in url
        d = {"id": uuid.uuid4().hex[:8], "url": url, "status": "paused" if hold else "queued", "files": [],
             "msg": "Added to the list · click ▶ Start download to begin" if hold else "",
             "profile": prof, "count": 0,
             "time": now().strftime("%m/%d %H:%M")}
        downloads.insert(0, d)
        del downloads[300:]
    save_dl()
    if not hold:
        dl_q.put(d["id"])
    return d, None


dl_procs = {}       # 다운로드 id -> 실행 중인 프로세스 (취소용)
dl_cancel = set()


def save_dl_log(d, cmd, txt):
    try:
        dlog = LOGDIR / "downloads"
        dlog.mkdir(parents=True, exist_ok=True)
        (dlog / f"{now():%m%d-%H%M%S}-{d['id']}.log").write_text(" ".join(cmd) + "\n\n" + txt, encoding="utf-8")
    except Exception:
        pass


def run_tool(cmd, d, stage=None, url=None, keep_log=False):
    """Run the tool; for full profiles, organize files as they arrive to show progress"""
    logf = DL_OUT / ".staging" / f"{d['id']}.log"
    try:
        logf.parent.mkdir(parents=True, exist_ok=True)
        with open(logf, "w", encoding="utf-8") as lf:
            p = spawn(cmd, cwd=str(stage or DL_OUT), stdout=lf, stderr=subprocess.STDOUT,
                      stdin=subprocess.DEVNULL, env=dict(os.environ, PYTHONIOENCODING="utf-8"))
            dl_procs[d["id"]] = p
            t0 = time.time()
            while p.poll() is None:
                time.sleep(3)
                if d.get("profile") and stage is not None:
                    add_placed(d, *organize(stage, url, min_idle=8))
                long_ = d.get("profile") or re.search(r"/i/(broadcasts|spaces)/|/live|/watch", d.get("url", ""))
                if time.time() - t0 > (8 * 3600 if long_ else 1800):   # X 방송·라이브 녹화는 길게 허용
                    hard_stop(p)
    except FileNotFoundError:
        return False, f"{cmd[0]} Program not found"
    finally:
        dl_procs.pop(d["id"], None)
    if d["id"] in dl_cancel:
        return False, "Cancelled"
    if p.returncode == 0:
        if keep_log:
            try:
                save_dl_log(d, cmd, ANSI.sub("", logf.read_text(encoding="utf-8", errors="replace"))[-20000:])
            except Exception:
                pass
        return True, ""
    try:
        txt = ANSI.sub("", logf.read_text(encoding="utf-8", errors="replace"))
        save_dl_log(d, cmd, txt)   # 원인 확인용
    except Exception:
        txt = ""
    cw = [l.strip() for l in txt.splitlines() if "cookie" in l.lower() and ("warn" in l.lower() or "error" in l.lower())]
    if cw:
        return False, ("Could not read browser login info: " + cw[-1])[-220:]
    lines = [l.strip() for l in txt.splitlines() if l.strip()]
    errs = [l for l in lines if "error" in l.lower()]
    msg = (errs or lines or ["Unknown error"])[-1]
    return False, msg[-200:]


def add_placed(d, placed, dup):
    if placed:
        d["count"] = d.get("count", 0) + len(placed)
        d["files"] = (placed + d.get("files", []))[:5]
        save_dl()


def dl_worker():
    while True:
        did = dl_q.get()
        d = next((x for x in downloads if x["id"] == did), None)
        if not d:
            continue
        dl_cancel.discard(did)
        d["status"] = "downloading"; d["count"] = 0; d["files"] = []; save_dl()
        url = d["url"]
        prof = d.get("profile")
        stage = DL_OUT / ".staging" / d["id"]
        stage.mkdir(parents=True, exist_ok=True)
        try:
            add_placed(d, *organize(stage, url))   # 지난번에 정리 못 한 파일이 있으면 먼저 정리
        except Exception:
            pass
        ok, msg = False, ""
        is_photo = "/photo/" in url
        ytdlp = tool("yt-dlp")
        gdl = tool("gallery-dl")
        tmpl = "%(uploader,channel,uploader_id|)s__C__%(upload_date>%Y-%m-%d|)s__D__%(id)s.%(ext)s"
        gfmt = "{date:%Y-%m-%d}__D__{id}_{num}.{extension}"
        is_ig = "instagram.com" in url
        is_x = bool(re.search(r"(^|//|\.)(x|twitter)\.com/", url))
        is_th = "threads." in url
        is_yt = bool(re.search(r"youtube\.com|youtu\.be", url))
        # 인스타·X·스레드는 로그인이 필요 → 앱 전용 Chrome 창에 로그인된 정보를 사용
        ck = ck_args("instagram" if is_ig else ("x" if is_x else "threads")) if (is_ig or is_x or is_th) else []
        ysort = ["-S", "vcodec:h264,res,acodec:m4a"] if is_yt else []      # 맥에서 바로 재생되는 H.264 우선
        if is_yt:
            tmpl = "%(uploader_id,uploader,channel|)s__C__%(upload_date>%Y-%m-%d|)s__D__%(id)s.%(ext)s"
        if is_x:
            gfmt = "{date:%Y-%m-%d}__D__{tweet_id|id}_{num}.{extension}"
        if is_ig:
            gfmt = "{username}__C__{date:%Y-%m-%d}__D__{post_shortcode|id}_{num}.{extension}"
        if prof:
            # 계정 전체: 영상은 yt-dlp, 놓친 영상·사진은 gallery-dl.
            # '이미 받음' 판단은 기록이 아니라 NAS·맥에 실제로 있는 파일 기준 → 사라진 파일은 다시 받음
            is_tt = "tiktok.com" in url
            tck = ck_args("tiktok") if is_tt else []
            if ytdlp and not (is_ig or is_x or is_th):     # yt-dlp 는 틱톡·유튜브 채널 전체 받기
                key = "tiktok" if is_tt else ("youtube" if "youtube" in url else "twitter")
                arch = DL_OUT / ".staging" / f"{d['id']}-archive.txt"
                arch.write_text("".join(f"{key} {i}\n" for i in sorted(present_ids(prof, stage))), encoding="utf-8")
                ok, msg = run_tool([ytdlp, "--yes-playlist", "--no-progress", "--ignore-errors",
                                    "-f", "bv*+ba/b", "--merge-output-format", "mp4",
                                    "--download-archive", str(arch),
                                    "--sleep-interval", "1", "--max-sleep-interval", "4",
                                    "-P", str(stage), "-o", tmpl] + tck + ysort + [url], d, stage, url, keep_log=True)
                try: arch.unlink()
                except Exception: pass
            if gdl and d["id"] not in dl_cancel:
                have = sorted(present_ids(prof, stage))
                field = "post_shortcode" if is_ig else ("str(tweet_id)" if is_x else "str(id)")
                flt = ["--filter", f"{field} not in {have!r}"] if have and not is_th else []
                extra = tck + flt
                if is_x or is_th:
                    extra = ck + flt + ["-o", "sleep-request=2-5"]
                    if is_x:
                        url_g = f"https://x.com/{prof}/media"      # 사진·영상 탭 전체
                if is_ig:   # 게시물 + 릴스 전체 (스토리·하이라이트는 제외), 계정 보호를 위해 천천히
                    extra = ck + flt + ["-o", "include=posts,reels", "-o", "sleep-request=4-9"]
                    url_g = f"https://www.instagram.com/{prof}/"
                ok2, msg2 = run_tool([gdl, "-D", str(stage), "-f", gfmt] + extra +
                                     [url_g if (is_ig or is_x) else url],
                                     d, stage, url, keep_log=True)
                if is_ig and not ok2 and d["id"] not in dl_cancel:
                    update_tools(force=True)
                    gdl = tool("gallery-dl")
                    ok2, msg2 = run_tool([gdl, "-D", str(stage), "-f", gfmt] + extra +
                                         ["-o", "api=graphql", "-o", "browser=chrome", url_g],
                                         d, stage, url)
                ok = ok or ok2
                msg = "" if ok else (msg or msg2)
        else:
            if not is_photo and ytdlp:
                ok, msg = run_tool([ytdlp, "--no-playlist", "--no-progress", "-f", "bv*+ba/b",
                                    "--merge-output-format", "mp4", "-P", str(stage), "-o", tmpl] + ck + ysort + [url], d)
            if not ok and gdl and d["id"] not in dl_cancel:   # 사진 게시물이나 yt-dlp가 못 받는 경우
                ok2, msg2 = run_tool([gdl, "-D", str(stage), "-f", gfmt] + ck + [url], d)
                if ok2:
                    ok, msg = True, ""
                elif not msg:
                    msg = msg2
        if not ytdlp and not gdl:
            msg = "yt-dlp / gallery-dl are not installed"
        if is_ig and not ok and not ig_state():
            msg = "Instagram login required — log in with the 🔑 Instagram login button above, then click ↻ Retry"
        elif is_ig and not ok and re.search(r"login|log in|401|403|keychain|redirect|NotFoundError|could not be found", msg, re.I) \
                and "read browser login info" not in msg:
            msg = "Instagram login required — log in, then click ↻ Retry"
        try:
            placed, dup = organize(stage, url)      # 남은 파일 마무리 정리 (취소돼도 받은 건 보관)
            add_placed(d, placed, dup)
            shutil.rmtree(stage, ignore_errors=True)
        except Exception as e:
            dup = 0
            msg = msg or f"Error while organizing files (downloads were kept): {e}"[:200]
        try:
            (DL_OUT / ".staging" / f"{d['id']}.log").unlink()
        except Exception:
            pass
        n = d.get("count", 0)
        if restarting:
            continue
        if did in dl_cancel:
            d["status"] = "error"; d["msg"] = f"Cancelled (got {n} items so far)"
        elif prof and (ok or n):
            d["status"] = "done"; d["msg"] = f"New posts: {n} downloaded" if n else "No new posts"
            notify(f"@{prof} Full download complete — {n} items")
        elif ok and n:
            d["status"] = "done"; d["msg"] = ""
            notify(f"Done: {d['files'][0]}" + (f" + {n-1} items" if n > 1 else ""))
        elif ok:
            d["status"] = "done"; d["msg"] = "Already downloaded" if dup else "Nothing was downloaded"
        else:
            d["status"] = "error"; d["msg"] = msg or "Download failed"
            notify("Download failed — check the reason in the app")
        save_dl()


def cancel_dl(did):
    d = next((x for x in downloads if x["id"] == did), None)
    if not d:
        return
    dl_cancel.add(did)
    if d["status"] == "queued":
        d["status"] = "error"; d["msg"] = "Cancelled"; save_dl()
    hard_stop(dl_procs.get(did))


def safe_file(rel):
    """Only allow opening/deleting files inside managed folders"""
    roots = [DL_OUT] + ([Path(settings["nas"])] if nas_ok else [])
    for root in roots:
        try:
            p = (root / rel).resolve()
            if root.resolve() in p.parents and p.is_file():
                return p
        except Exception:
            pass
    return None


def trash(p):
    """Move to Trash / Recycle Bin so it can be restored"""
    try:
        from send2trash import send2trash
        send2trash(str(p))
        return True
    except Exception:
        pass
    if IS_MAC:
        ps = str(p).replace("\\", "\\\\").replace('"', '\\"')
        try:
            r = subprocess.run(["osascript", "-e", f'tell application "Finder" to delete (POSIX file "{ps}")'],
                               capture_output=True, timeout=15)
            if r.returncode == 0:
                return True
        except Exception:
            pass
    return False


def present_ids(creator, stage=None):
    """Post ids that already exist for the creator (from 'date_id[_n].ext' file names)"""
    import unicodedata
    ids = set()
    roots = [DL_OUT] + ([Path(settings["nas"])] if nas_ok else [])
    want = unicodedata.normalize("NFC", safe_name(creator))
    for root in roots:
        try:
            for cdir in root.iterdir():
                if unicodedata.normalize("NFC", cdir.name) != want or not cdir.is_dir():
                    continue
                for f in cdir.glob("*/*"):
                    m = re.match(r"^\d{4}-\d{2}-\d{2}_(.+?)(?:_\d{1,3})?\.[A-Za-z0-9]+$", f.name)
                    if m:
                        ids.add(m.group(1))
        except Exception:
            pass
    if stage is not None:   # 이번 실행에서 막 받은(아직 정리 전) 파일
        try:
            for f in stage.rglob("*__D__*"):
                m = re.search(r"__D__(.+?)(?:_\d{1,3})?\.[A-Za-z0-9]+$", f.name)
                if m:
                    ids.add(m.group(1))
        except Exception:
            pass
    return ids


def creator_folder(creator, kind=None):
    """Find the existing folder (NAS first, then local); else the nearest parent"""
    import unicodedata
    want = [unicodedata.normalize("NFC", safe_name(creator))] + ([kind] if kind else [])
    roots = ([Path(settings["nas"])] if nas_ok else []) + [DL_OUT]
    best = None
    for root in roots:
        cur, depth = root, 0
        for part in want:
            hit = None
            try:
                for c in cur.iterdir():
                    if c.is_dir() and unicodedata.normalize("NFC", c.name) == unicodedata.normalize("NFC", part):
                        hit = c; break
            except Exception:
                pass
            if not hit:
                break
            cur, depth = hit, depth + 1
        if depth == len(want):
            return cur
        if best is None or depth > best[1]:
            best = (cur, depth)
    return best[0] if best else final_root()


def creator_from_url(url):
    try:
        from urllib.parse import urlparse
        u = urlparse(url)
    except Exception:
        return None
    host = (u.hostname or "").lower()
    segs = [s for s in u.path.split("/") if s]
    m = re.search(r"/@([A-Za-z0-9._-]{1,60})", u.path)
    if m and any(h in host for h in ("tiktok.", "youtube.", "threads.")):
        return m.group(1)
    if any(h in host for h in ("x.com", "twitter.com")) and segs and segs[0] not in ("i", "home", "search", "hashtag"):
        return segs[0]
    if "instagram.com" in host and segs:
        if segs[0] == "stories" and len(segs) > 1:
            return segs[1]
        if segs[0] not in ("p", "reel", "reels", "tv", "explore", "stories") and len(segs) > 1:
            return segs[0]
    return None


PARTIAL = re.compile(r"(\.part|\.ytdl|\.temp(\.\w+)?|\.f\d+\.\w+|\.part-Frag\d+)$")


def organize(stage, url, min_idle=0):
    """Move downloads to <creator>/<Videos|Photos>/<date>_<id>.<ext>"""
    placed, dup = [], 0
    today = now().strftime("%Y-%m-%d")
    url_creator = creator_from_url(url)
    t = time.time()
    try:
        items = sorted(stage.rglob("*"))
    except Exception:
        return placed, dup
    for f in items:
        if not f.is_file() or PARTIAL.search(f.name) or f.name.startswith(".") or f.suffix == ".log":
            continue
        try:
            if min_idle and t - f.stat().st_mtime < min_idle:   # 아직 쓰는 중
                continue
        except Exception:
            continue
        ext = f.suffix.lower().lstrip(".")
        name = f.stem
        meta_creator, date, rest = None, None, name
        if "__D__" in name:
            left, rest = name.split("__D__", 1)
            if "__C__" in left:
                meta_creator, date = left.split("__C__", 1)
            else:
                date = left
        if not date or not re.match(r"^\d{4}-\d{2}-\d{2}$", date):
            date = today
        if meta_creator in ("None", "", "NA"):
            meta_creator = None
        if meta_creator:
            meta_creator = meta_creator.lstrip("@")
        creator = url_creator or meta_creator or "Other"
        if ext in VIDEO_EXT:
            rest = re.sub(r"_\d{1,2}$", "", rest)
        kind = "Photos" if ext in IMAGE_EXT else "Videos"
        target = kind_dir(creator, kind, final_root()) / f"{date}_{safe_name(rest, 'file')}.{ext}"
        if target.exists():
            dup += 1
            try:
                f.unlink()
            except Exception:
                pass
            continue
        try:
            shutil.move(str(f), str(target))
        except Exception:
            # NAS 문제 등으로 못 옮기면 맥에 보관 (나중에 자동으로 NAS로 이동)
            target = kind_dir(creator, kind, DL_OUT) / target.name
            shutil.move(str(f), str(target))
        placed.append(f"{safe_name(creator)}/{kind}/{target.name}")
    return placed, dup


TOOLS = DATA            # 도구는 모두 앱 전용 환경(DATA/env)과 DATA/bin 에 설치됨
EXE = ".exe" if IS_WIN else ""


def tool(name):
    """Find a program: app env → DATA/bin → system"""
    for d in (ENV_BIN, BIN):
        for cand in (d / (name + EXE), d / name):
            if cand.exists():
                return str(cand)
    return shutil.which(name)


def uv_bin():
    for c in (shutil.which("uv"), str(HOME / ".local" / "bin" / ("uv" + EXE)), str(DATA / "uv" / ("uv" + EXE))):
        if c and Path(c).exists():
            return c
    return None


def install_log():
    return open(LOGDIR / "install.log", "a", encoding="utf-8")


def ensure_ffmpeg():
    """Copy ffmpeg from imageio-ffmpeg into DATA/bin if missing"""
    target = BIN / ("ffmpeg" + EXE)
    if target.exists():
        return str(target)
    try:
        import imageio_ffmpeg
        src = imageio_ffmpeg.get_ffmpeg_exe()
        shutil.copy2(src, target)
        if not IS_WIN:
            os.chmod(target, 0o755)
        return str(target)
    except Exception:
        return shutil.which("ffmpeg")


def update_tools(force=False):
    """Update gallery-dl / yt-dlp / ffmpeg once a day"""
    stamp = SUP / ".tools-updated"
    if stamp.exists() and time.time() - stamp.stat().st_mtime < (3600 if force else 86400):
        return
    uv = uv_bin()
    try:
        with install_log() as lf:
            lf.write(f"\n== {now()} download tools update\n"); lf.flush()
            base = [uv, "pip", "install", "-p", sys.executable] if uv else [sys.executable, "-m", "pip", "install"]
            r = run_quiet(base + ["-U", "gallery-dl", "yt-dlp[default,curl-cffi]", "imageio-ffmpeg"],
                          stdout=lf, stderr=subprocess.STDOUT, timeout=900)
            if r.returncode == 0:
                stamp.touch()
                try:
                    (BIN / ("ffmpeg" + EXE)).unlink()       # 새 ffmpeg 로 교체
                except Exception:
                    pass
                ensure_ffmpeg()
    except Exception:
        pass


upd = {"last": "", "running": False, "msg": ""}
REC_ZIP = "https://github.com/Michele0303/tiktok-live-recorder/archive/refs/heads/main.zip"


def update_recorder():
    """Update tiktok-live-recorder — only when not recording"""
    if any(p.poll() is None for p in procs.values()):
        return "Recording in progress — recorder update postponed"
    import urllib.request, zipfile, tempfile
    try:
        with install_log() as lf:
            lf.write(f"\n== {now()} recorder update\n"); lf.flush()
            with tempfile.TemporaryDirectory() as td:
                zp = Path(td) / "rec.zip"
                urllib.request.urlretrieve(REC_ZIP, zp)
                with zipfile.ZipFile(zp) as z:
                    z.extractall(td)
                src = next(Path(td).glob("tiktok-live-recorder-*"))
                keep = {}
                for name in ("cookies.json", "telegram.json"):        # 사용자 설정은 유지
                    f = REC_DIR / "src" / name
                    if f.exists():
                        keep[name] = f.read_bytes()
                new = REC_DIR.with_name("recorder.new")
                shutil.rmtree(new, ignore_errors=True)
                shutil.copytree(src, new)
                for name, data in keep.items():
                    (new / "src" / name).write_bytes(data)
                old = REC_DIR.with_name("recorder.old")
                shutil.rmtree(old, ignore_errors=True)
                if REC_DIR.exists():
                    REC_DIR.rename(old)
                new.rename(REC_DIR)
                shutil.rmtree(old, ignore_errors=True)
            uv = uv_bin()
            base = [uv, "pip", "install", "-p", sys.executable] if uv else [sys.executable, "-m", "pip", "install"]
            r = run_quiet(base + ["-r", str(REC_DIR / "pyproject.toml")], stdout=lf, stderr=subprocess.STDOUT, timeout=900)
        return "" if r.returncode == 0 else "Recorder update failed (see log)"
    except Exception as e:
        return f"Recorder update failed: {e}"[:150]


def update_all(force=False):
    """Auto-update tools, recorder and ffmpeg once a day"""
    stamp = SUP / ".all-updated"
    if not force and stamp.exists() and time.time() - stamp.stat().st_mtime < 86400:
        return
    if upd["running"]:
        return
    upd["running"] = True; upd["msg"] = "Updating…"
    try:
        if force:   # '지금 업데이트'는 시간 제한 없이 바로
            try: (SUP / ".tools-updated").unlink()
            except Exception: pass
        update_tools()
        msg = update_recorder()
        stamp.touch()
        upd["last"] = now().strftime("%m/%d %H:%M")
        upd["msg"] = msg
    finally:
        upd["running"] = False


def updater_loop():
    time.sleep(60)          # 앱이 켜지고 1분 뒤부터
    while True:
        try:
            update_all()
        except Exception as e:
            upd["msg"] = str(e)[:150]
        time.sleep(3600)    # 1시간마다 '하루 지났는지' checked


def ensure_tools():
    """Prepare ffmpeg on start and update tools if needed"""
    ensure_ffmpeg()
    if not REC_DIR.exists():
        update_recorder()
    update_tools()


LIVE_RE = re.compile(r"tiktok\.com/@([A-Za-z0-9._]{1,40})/live", re.I)
LIVE_YT_RE = re.compile(r"youtube\.com/@([A-Za-z0-9._-]{1,60})/live", re.I)
LIVE_IG_RE = re.compile(r"instagram\.com/([A-Za-z0-9._]{1,40})/live", re.I)
SHORT_RE = re.compile(r"^https?://(vm|vt)\.tiktok\.com/", re.I)


def resolve(url):
    """Expand short share links like vt.tiktok.com"""
    if not SHORT_RE.match(url):
        return url
    import urllib.request, urllib.error
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                                               "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36"})
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            return r.geturl()
    except urllib.error.HTTPError as e:
        return e.geturl() or url
    except Exception:
        return url


def route(url):
    """Route live links to recording, others to download. Returns (kind, error)"""
    url = url.strip()
    if not URL_RE.match(url):
        return None, "Unsupported link (TikTok, YouTube, Instagram, X, …)"
    real = resolve(url)
    m = LIVE_RE.search(real) or LIVE_IG_RE.search(real) or LIVE_YT_RE.search(real)
    if m:
        user = m.group(1)
        pf = "instagram" if "instagram.com" in real else ("youtube" if "youtube.com" in real else "tiktok")
        mode = "auto" if settings.get("live_mode") == "auto" else "now"
        code, res = add_jobs({"user": user, "mode": mode, "interval": 5, "platform": pf})
        if code != 200:
            return None, res.get("error")
        with lock:   # 라이브는 다운로드 기록이 아니라 라이브 녹화 화면의 진행 상태에만 표시
            for jid in res.get("ids", []):
                if jid in jobs:
                    jobs[jid]["src"] = "Clipboard"
        save()
        notify(f"🔴 @{user} live recording started")
        return "live", None
    pu = profile_of(real)
    if pu and "tiktok.com" in real:   # 틱톡 프로필이면 카드에 쓸 프로필 사진도 받아 둠
        threading.Thread(target=check_live, args=(pu,), daemon=True).start()
    d, err = enqueue(real if SHORT_RE.match(url) and URL_RE.match(real) else url)
    if err:
        return None, err
    notify("📋 YouTube channel added to the list (click Start download to begin)" if d.get("status") == "paused" else "⬇️ Download started")
    return "download", None


# ───────────────────────── NAS 저장 / 자동 이동 ─────────────────────────
nas_ok = False
nas_pending = 0
nas_error = ""
nas_live_cache = []
_last_mount_try = 0.0


def _with_timeout(fn, sec=6, default=None):
    """Time limit so an unresponsive network drive cannot freeze the app"""
    box = [default]
    t = threading.Thread(target=lambda: box.__setitem__(0, fn()), daemon=True)
    t.start(); t.join(sec)
    return box[0]


def check_nas():
    global nas_ok, _last_mount_try
    nas = settings.get("nas")
    if not nas or not NAS_ENABLED:
        nas_ok = False
        return False
    p = Path(nas)
    ok = _with_timeout(lambda: p.is_dir() and os.access(p, os.W_OK), 6, False)
    if not ok and sys.platform == "darwin" and settings.get("nas_url") and time.time() - _last_mount_try > 180:
        _last_mount_try = time.time()
        try_mount()
        ok = _with_timeout(lambda: p.is_dir() and os.access(p, os.W_OK), 6, False)
    nas_ok = bool(ok)
    return nas_ok


def try_mount():
    """Try to mount the NAS only when it is visible on the network"""
    import socket
    from urllib.parse import urlparse
    url = settings.get("nas_url", "")
    host = urlparse(url).hostname or ""
    if "._smb._tcp" in host:
        host = host.split("._smb._tcp")[0] + ".local"
    try:
        socket.create_connection((host, 445), timeout=3).close()
    except Exception:
        return
    if not IS_MAC:
        return            # 윈도우는 \\NAS이름\폴더 경로를 그대로 쓰므로 따로 연결할 필요 없음
    u = url.replace('"', "")
    subprocess.run(["osascript", "-e", f'try\nmount volume "{u}"\nend try'],
                   capture_output=True, timeout=40)


def final_root():
    return Path(settings["nas"]) if nas_ok else DL_OUT


def final_files():
    """Finished local files that can move to the NAS"""
    t = time.time()
    out = []
    for f in DL_OUT.glob("*/*/*"):
        rel = f.relative_to(DL_OUT)
        # 앱이 만든 파일만: <크리에이터>/<라이브|동영상|사진>/<파일>  (원래 있던 다른 파일·폴더는 절대 건드리지 않음)
        if len(rel.parts) != 3 or rel.parts[1] not in ("Live", "Videos", "Photos"):
            continue
        if not f.is_file() or rel.parts[0].startswith(".") or f.name.startswith("."):
            continue
        if not DATE_PREFIX.match(f.name):
            continue
        if PARTIAL.search(f.name):
            continue
        try:
            age = t - f.stat().st_mtime
        except Exception:
            continue
        if len(rel.parts) >= 2 and rel.parts[1] == "Live":
            if age < 150 or not DATE_PREFIX.match(f.name):   # 녹화 중이거나 아직 이름 정리 전
                continue
        elif age < 10:
            continue
        out.append(f)
    return out


def nas_sync():
    global nas_pending, nas_error, nas_live_cache
    while True:
        try:
            check_nas()
            files = final_files()
            if nas_ok:
                root = Path(settings["nas"])
                for f in files:
                    rel = f.relative_to(DL_OUT)
                    try:
                        dest = ensure_dir(root, *rel.parts[:-1]) / rel.parts[-1]
                        if dest.exists() and dest.stat().st_size == f.stat().st_size:
                            f.unlink()          # 이미 NAS에 같은 파일이 있음
                            continue
                        dest = unique_path(dest)
                        tmp = dest.with_name(dest.name + ".copying")
                        shutil.copy2(str(f), str(tmp))
                        if tmp.stat().st_size != f.stat().st_size:
                            raise IOError("copied size mismatch")
                        tmp.rename(dest)
                        f.unlink()
                        nas_error = ""
                    except Exception as e:
                        nas_error = f"Moving to NAS failed: {e}"[:200]
                        try:
                            tmp.unlink()
                        except Exception:
                            pass
                        break
                # 빈 폴더 정리 (맥 쪽)
                for d in sorted(DL_OUT.glob("*/*"), reverse=True):
                    try:
                        if d.is_dir() and d.name in ("Videos", "Photos") and not any(d.iterdir()) and not d.parent.name.startswith("."):
                            d.rmdir()
                    except Exception:
                        pass
                nas_live_cache = _with_timeout(
                    lambda: sorted((x for x in root.glob("*/Live/*") if x.is_file() and not x.name.startswith(".")
                                    and not x.name.endswith(".copying")),
                                   key=lambda x: x.stat().st_mtime, reverse=True)[:12], 10, []) or []
            else:
                nas_live_cache = []
            nas_pending = len(final_files())
        except Exception as e:
            nas_error = str(e)[:200]
        time.sleep(20)


# ───────────────────────── 인스타그램 전용 로그인 창 ─────────────────────────
COOKIE_DIR = SUP / "cookies"
LOGIN_COOKIE = {"instagram": ("instagram.com", ("sessionid",)), "tiktok": ("tiktok.com", ("sessionid", "sessionid_ss")),
                "x": ("x.com", ("auth_token",)), "threads": ("threads", ("sessionid", "sessionid_ss"))}


def cookie_file(site):
    """Cookie file saved by the app login window (or None)"""
    f = COOKIE_DIR / f"{site}.txt"
    return f if f.exists() and f.stat().st_size > 0 else None


def logged_in(site):
    f = cookie_file(site)
    if not f:
        return False
    dom, names = LOGIN_COOKIE.get(site, (site, ("sessionid",)))
    try:
        for line in f.read_text(encoding="utf-8", errors="replace").splitlines():
            parts = line.split("\t")
            if len(parts) >= 7 and dom in parts[0] and parts[5] in names and parts[6].strip():
                return True
    except Exception:
        pass
    return False


def ck_args(site):
    f = cookie_file(site)
    return ["--cookies", str(f)] if f else []


_ig_cache = [0.0, {}]


def login_states():
    if time.time() - _ig_cache[0] > 5:
        _ig_cache[:] = [time.time(), {k: logged_in(k) for k in LOGIN_COOKIE}]
    return _ig_cache[1]


def ig_state():
    return login_states().get("instagram", False)


def tt_state():
    return login_states().get("tiktok", False)


def write_recorder_cookies():
    """Put TikTok login into the recorder config so login-only lives can be recorded"""
    f = cookie_file("tiktok")
    if not f:
        return
    vals = {}
    try:
        for line in f.read_text(encoding="utf-8", errors="replace").splitlines():
            parts = line.split("\t")
            if len(parts) >= 7 and "tiktok.com" in parts[0] and parts[5] in ("sessionid_ss", "sessionid", "tt-target-idc"):
                vals[parts[5]] = parts[6].strip()
        if vals:
            cj = REC_DIR / "src" / "cookies.json"
            cur = {}
            try:
                cur = json.loads(cj.read_text(encoding="utf-8"))
            except Exception:
                pass
            cur["sessionid_ss"] = vals.get("sessionid_ss") or vals.get("sessionid") or cur.get("sessionid_ss", "")
            if vals.get("tt-target-idc"):
                cur["tt-target-idc"] = vals["tt-target-idc"]
            cj.write_text(json.dumps(cur, indent=2), encoding="utf-8")
    except Exception:
        pass


def clip_watcher():
    last = None
    while True:
        try:
            cur = clipboard_text()
        except Exception:
            cur = last
        if last is None:          # 앱을 켤 때 이미 복사돼 있던 주소는 무시
            last = cur
        elif cur != last:
            last = cur
            if settings.get("clip") and cur and len(cur) < 600 and cur not in seen and URL_RE.match(cur):
                seen.add(cur)
                threading.Thread(target=route, args=(cur,), daemon=True).start()
        time.sleep(1)


last_seen = 0.0   # 앱 창이 마지막으로 상태를 요청한 시각 (창이 열려 있는지 판단)


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        b = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "max-age=3600" if ctype == "image/jpeg" else "no-store")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            return self._send(200, HTML_FILE.read_bytes(), "text/html; charset=utf-8")
        global last_seen
        if self.path == "/api/ping":
            return self._send(200, {"ok": True, "window": time.time() - last_seen < 75, "version": APP_VERSION})
        if self.path == "/api/state":
            last_seen = time.time()
            return self._send(200, state_payload())
        from urllib.parse import urlparse, parse_qs, unquote
        u = urlparse(self.path)
        if u.path == "/api/remote":
            return self._send(200, remote_info())
        if u.path == "/api/remote/qr":
            svg = qr_svg(parse_qs(u.query).get("u", [""])[0])
            return self._send(200, svg, "image/svg+xml") if svg else self._send(404, {"error": "qr"})
        if u.path.startswith("/avatar/"):
            f = AV_DIR / f"{safe_name(unquote(u.path[8:]))}.jpg"
            if f.exists():
                return self._send(200, f.read_bytes(), "image/jpeg")
            return self._send(404, {"error": "no avatar"})
        if u.path == "/cthumb":
            q = parse_qs(u.query)
            p = safe_file(q.get("p", [""])[0]) if q.get("p") else None
            if not p:
                p = latest_media(q.get("c", [""])[0])
            t = make_thumb(p) if p else None
            if t:
                return self._send(200, t.read_bytes(), "image/jpeg")
            return self._send(404, {"error": "no thumb"})
        if u.path == "/thumb":
            p = safe_file(parse_qs(u.query).get("p", [""])[0])
            if p:
                ext = p.suffix.lower().lstrip(".")
                t = make_thumb(p) if ext in VIDEO_EXT or ext in IMAGE_EXT else None
                if t:
                    return self._send(200, t.read_bytes(), "image/jpeg")
            return self._send(404, {"error": "no thumb"})
        self._send(404, {"error": "not found"})

    def do_POST(self):
        global last_seen
        if self.path == "/api/bye":               # 창을 닫을 때 보내는 신호
            last_seen = 0.0
            return self._send(200, {"ok": True})
        if self.headers.get("X-App") != "tlr":   # 다른 웹사이트에서 보내는 요청 차단
            return self._send(403, {"error": "forbidden"})
        n = int(self.headers.get("Content-Length") or 0)
        try:
            body = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            body = {}
        parts = self.path.strip("/").split("/")
        if self.path == "/api/jobs":
            return self._send(*add_jobs(body))
        if len(parts) == 4 and parts[:2] == ["api", "jobs"] and parts[2] in jobs:
            jid, act = parts[2], parts[3]
            j = jobs[jid]
            if act == "start":
                if j["mode"] == "smart" and j["state"] != "running":
                    j["state"] = "armed"; save()
                    return self._send(200, {"ok": True})
                if j["mode"] == "schedule" and j["state"] in ("idle", "stopped", "done", "error"):
                    try:
                        if datetime.fromisoformat(j["start_at"]) > now():
                            j["state"] = "scheduled"; save()
                            return self._send(200, {"ok": True})
                    except Exception:
                        pass
                start_job(jid)
            elif act == "stop":
                stop_job(jid)
            elif act == "delete":
                stop_job(jid)
                with lock:
                    jobs.pop(jid, None)
                save()
            return self._send(200, {"ok": True})
        if self.path == "/api/open-folder":
            open_path(final_root())
            return self._send(200, {"ok": True})
        if self.path == "/api/open-dl":
            open_path(final_root())
            return self._send(200, {"ok": True})
        if self.path == "/api/storage":
            global DL_OUT, OUT
            lv = str(body.get("local", "")).strip()
            if lv:                                   # 내 컴퓨터 저장 폴더 바꾸기
                if not os.path.isabs(os.path.expanduser(lv)):
                    return self._send(400, {"error": "Please enter the full path for the save folder"})
                try:
                    newp = Path(os.path.expanduser(lv)); newp.mkdir(parents=True, exist_ok=True)
                except Exception as e:
                    return self._send(400, {"error": f"Cannot create the folder: {e}"})
                settings["local"] = str(newp); DL_OUT = OUT = newp
            if not NAS_ENABLED:
                save_dl()
                return self._send(200, {"ok": True})
            v = str(body.get("nas", "")).strip()
            if v and not (os.path.isabs(v) or v.startswith("\\\\")):
                return self._send(400, {"error": "Enter the full NAS path (Mac: /Volumes/…, Windows: \\\\NAS\\folder or Z:\\…)"})
            settings["nas"] = v
            if body.get("nas_url") is not None:
                settings["nas_url"] = str(body["nas_url"]).strip()
            save_dl()
            threading.Thread(target=check_nas, daemon=True).start()
            return self._send(200, {"ok": True})
        if self.path == "/api/clip":
            if "on" in body:
                settings["clip"] = bool(body.get("on"))
            if body.get("live_mode") in ("now", "auto"):
                settings["live_mode"] = body["live_mode"]
            save_dl()
            return self._send(200, {"ok": True})
        if self.path == "/api/download":
            pu = profile_of(str(body.get("url", "")))
            if pu and "tiktok.com" in str(body.get("url", "")):
                threading.Thread(target=check_live, args=(pu,), daemon=True).start()
            kind, err = route(str(body.get("url", "")))
            return self._send(400, {"error": err}) if err else self._send(200, {"ok": True, "kind": kind})
        if self.path == "/api/dl-clear":
            with lock:
                downloads[:] = [x for x in downloads if x["status"] in ("queued", "downloading", "paused")]
            save_dl()
            return self._send(200, {"ok": True})
        if self.path == "/api/update":
            threading.Thread(target=update_all, args=(True,), daemon=True).start()
            return self._send(200, {"ok": True})
        if self.path == "/api/profile":   # 프로필: 크리에이터의 SNS 프로필 페이지를 기본 브라우저로 열기
            u = str(body.get("user", "")).lstrip("@")
            site = str(body.get("site", "tiktok"))
            if not re.match(r"^[A-Za-z0-9._-]{1,60}$", u):
                return self._send(400, {"error": "Invalid username"})
            urls = {"tiktok": f"https://www.tiktok.com/@{u}", "instagram": f"https://www.instagram.com/{u}/",
                    "x": f"https://x.com/{u}", "youtube": f"https://www.youtube.com/@{u}",
                    "threads": f"https://www.threads.net/@{u}"}
            open_url(urls.get(site, urls["tiktok"]))
            return self._send(200, {"ok": True})
        if self.path == "/api/watch":   # 시청: 그 계정의 틱톡 라이브 페이지를 기본 브라우저로 열기
            u = str(body.get("user", "")).lstrip("@")
            if not re.match(r"^[A-Za-z0-9._-]{1,60}$", u):
                return self._send(400, {"error": "Invalid username"})
            site_ = body.get("site")
            open_url(f"https://www.instagram.com/{u}/live/" if site_ == "instagram"
                     else (f"https://www.youtube.com/@{u}/live" if site_ == "youtube"
                           else f"https://www.tiktok.com/@{u}/live"))
            return self._send(200, {"ok": True})
        if self.path == "/api/open-creator":   # 카드의 '폴더 열기': 그 크리에이터(·종류) 폴더를 바로 열기
            open_path(creator_folder(str(body.get("creator", "")), body.get("kind")))
            return self._send(200, {"ok": True})
        if self.path == "/api/ig-login":   # 로그인은 앱 창(로그인 창)에서만 가능
            return self._send(400, {"error": "Please log in from the SNS Content Manager app window"})
            return self._send(200, {"ok": True})
        if self.path == "/api/dl-bulk":      # 다운로드: 전체 시작 / 전체 중단 / 선택 삭제
            act, ids = body.get("action"), set(body.get("ids") or [])
            n = 0
            for d in list(downloads):
                if ids and d["id"] not in ids:
                    continue
                if act == "start" and d["status"] in ("error", "paused"):
                    d["status"] = "queued"; d["msg"] = ""; dl_q.put(d["id"]); n += 1
                elif act == "stop" and d["status"] in ("queued", "downloading"):
                    cancel_dl(d["id"]); n += 1
                elif act == "delete" and ids:
                    if d["status"] in ("queued", "downloading"):
                        cancel_dl(d["id"])
                    with lock:
                        if d in downloads:
                            downloads.remove(d)
                    n += 1
            save_dl()
            return self._send(200, {"ok": True, "n": n})
        if self.path == "/api/jobs-bulk":    # 라이브: 전체 시작 / 전체 중단 / 선택 삭제
            act, ids = body.get("action"), set(body.get("ids") or [])
            n = 0
            for jid, j in list(jobs.items()):
                if ids and jid not in ids:
                    continue
                if act == "start" and j["state"] in ("idle", "stopped", "done", "error"):
                    if j["mode"] == "smart":
                        j["state"] = "armed"
                    elif j["mode"] == "schedule" and j.get("start_at") and datetime.fromisoformat(j["start_at"]) > now():
                        j["state"] = "scheduled"
                    else:
                        start_job(jid)
                    n += 1
                elif act == "stop" and j["state"] in ("running", "starting", "armed", "scheduled"):
                    stop_job(jid); n += 1
                elif act == "delete" and ids:
                    stop_job(jid)
                    with lock:
                        jobs.pop(jid, None)
                    n += 1
            save()
            return self._send(200, {"ok": True, "n": n})
        if len(parts) == 3 and parts[:2] == ["api", "dl-remove"]:   # 기록 한 줄만 지우기 (파일은 그대로)
            with lock:
                downloads[:] = [x for x in downloads if not (x["id"] == parts[2] and x["status"] not in ("queued", "downloading"))]
            save_dl()
            return self._send(200, {"ok": True})
        if len(parts) == 3 and parts[:2] == ["api", "dl-cancel"]:
            cancel_dl(parts[2])
            return self._send(200, {"ok": True})
        if self.path in ("/api/file/open", "/api/file/reveal", "/api/file/trash"):
            p = safe_file(str(body.get("path", "")))
            if not p:
                return self._send(404, {"error": "File not found"})
            if self.path.endswith("open"):
                open_path(p)
            elif self.path.endswith("reveal"):
                reveal(p)
            elif not trash(p):
                return self._send(500, {"error": "Could not move to Trash"})
            return self._send(200, {"ok": True})
        if len(parts) == 3 and parts[:2] == ["api", "dl-retry"]:
            d = next((x for x in downloads if x["id"] == parts[2]), None)
            if d and (d["status"] in ("error", "paused") or (d["status"] == "done" and d.get("profile"))):
                d["status"] = "queued"; d["msg"] = ""; save_dl(); dl_q.put(d["id"])
            return self._send(200, {"ok": True})
        if self.path == "/api/remote":            # 📱 아이폰 연결 켜기/끄기 · 새 주소 만들기
            if not REMOTE_ENABLED:
                return self._send(400, {"error": "Not available in this edition"})
            if body.get("regen"):
                settings["remote_token"] = ""
                remote_token()
                _addr_cache[0] = 0.0
            if "on" in body:
                settings["remote_on"] = bool(body["on"])
                save_dl()
                if settings["remote_on"]:
                    remote_start()
                else:
                    remote_stop()
            return self._send(200, remote_info())
        if self.path == "/api/stop-all":
            for jid in list(jobs):
                if jobs[jid]["state"] in ("running", "starting"):
                    stop_job(jid)
            return self._send(200, {"ok": True})
        if self.path == "/api/restart":
            self._send(200, {"ok": True})
            threading.Thread(target=graceful_exit, daemon=True).start()
            return
        if self.path == "/api/quit":
            self._send(200, {"ok": True})
            threading.Thread(target=shutdown, daemon=True).start()
            return
        self._send(404, {"error": "not found"})


def add_jobs(b):
    users = []      # [(계정, 플랫폼)]
    default_pf = b.get("platform") if b.get("platform") in ("instagram", "youtube") else "tiktok"
    for tok in re.split(r"[,\s]+", str(b.get("user", ""))):
        tok = tok.strip()
        if not tok:
            continue
        mi = re.search(r"instagram\.com/([A-Za-z0-9._]{1,40})", tok)
        my = re.search(r"youtube\.com/@([A-Za-z0-9._-]{1,60})", tok)
        if my:                                              # 유튜브 채널 주소
            item = (my.group(1), "youtube")
        elif re.search(r"youtu\.be/|youtube\.com/(watch|live/|shorts/)", tok):   # 유튜브 영상 주소 → 채널 찾기
            h = resolve_yt_channel(tok)
            if not h:
                return 400, {"error": "Could not find the YouTube channel. Enter the channel URL (youtube.com/@name)."}
            item = (h, "youtube")
        elif mi and mi.group(1) not in RESERVED_IG:          # 인스타 주소 → 인스타 계정
            item = (mi.group(1), "instagram")
        else:
            m = re.search(r"@([A-Za-z0-9._]{1,40})", tok)   # 틱톡 주소를 통째로 붙여넣어도 @계정명만 추출
            item = (m.group(1), "tiktok") if m and "tiktok" in tok else ((m.group(1) if m else tok.lstrip("@")), default_pf)
        if item not in users:
            users.append(item)
    if not users:
        return 400, {"error": "Enter a username."}
    bad = [u for u, pf_ in users if not (re.match(r"^[A-Za-z0-9._-]{1,60}$", u) if pf_ == "youtube" else USER_RE.match(u))]
    if bad:
        return 400, {"error": f"Invalid username format: {', '.join(bad)}"}
    mode = b.get("mode")
    if mode not in ("auto", "now", "schedule", "smart"):
        return 400, {"error": "Choose a recording mode."}
    start_at = None
    dur = None
    if mode == "schedule":
        try:
            start_at = datetime.fromisoformat(b.get("start_at", "")).isoformat(timespec="seconds")
        except Exception:
            return 400, {"error": "Enter a start time."}
        if b.get("duration_min"):
            try:
                dur = max(1, int(b["duration_min"]))
            except Exception:
                return 400, {"error": "Enter the duration as a number (minutes)."}
    try:
        interval = max(1, min(60, int(b.get("interval") or 5)))
    except Exception:
        interval = 5
    created = []
    for u, pf in users:
        dup = next((x for x in jobs.values() if x["user"].lower() == u.lower() and x["mode"] == mode
                    and x.get("platform", "tiktok") == pf and mode != "schedule"), None)
        if dup:   # 같은 계정·같은 방식이 이미 있으면 새로 만들지 않고 다시 시작
            start_job(dup["id"])
            created.append(dup["id"])
            continue
        jid = uuid.uuid4().hex[:8]
        with lock:
            jobs[jid] = {"id": jid, "user": u, "platform": pf, "mode": mode, "interval": interval,
                         "start_at": start_at, "duration_min": dur, "end_at": None,
                         "state": "idle", "created": now().isoformat(timespec="seconds")}
        created.append(jid)
        if mode == "schedule":
            if datetime.fromisoformat(start_at) <= now():
                start_job(jid, 1)
            else:
                jobs[jid]["state"] = "scheduled"
        elif mode == "smart":
            jobs[jid]["state"] = "armed"     # 정기 방송 자동: 예상 시간대·방송 시작 때 알아서 녹화 시작
        else:
            start_job(jid)
    save()
    return 200, {"ok": True, "ids": created}


# ───────────────────────── 📱 아이폰 연결 (개인판) ─────────────────────────
# 아이폰(같은 와이파이 또는 Tailscale)에서 주소를 보내거나 진행 상황을 볼 수 있는 작은 웹 서버.
# 앱 화면용 서버(127.0.0.1)와 따로 열고, 모든 요청에 비밀 주소(토큰)가 있어야만 응답함.
REMOTE_PORT = PORT + 2
REMOTE_ENABLED = True            # 개인판·배포판 모두 사용
MOBILE_FILE = APP_DIR / "mobile.html"
remote_srv = None
remote_err = ""
_URL_IN_TEXT = re.compile(r"https?://[^\s<>\"']+")


def remote_token():
    import secrets
    if not settings.get("remote_token"):
        settings["remote_token"] = secrets.token_urlsafe(12)
        save_dl()
    return settings["remote_token"]


_addr_cache = [0.0, []]


def local_addresses():
    if time.time() - _addr_cache[0] < 20:
        return _addr_cache[1]
    _addr_cache[0], _addr_cache[1] = time.time(), _local_addresses()
    return _addr_cache[1]


def _local_addresses():
    """Addresses for the iPhone: Tailscale (100.x) first, then home Wi-Fi"""
    import socket as _s
    ts, lan = [], []
    try:
        if IS_WIN:
            out = run_quiet(["ipconfig"], capture_output=True, text=True, timeout=5, errors="replace").stdout or ""
        else:
            out = run_quiet(["ifconfig"], capture_output=True, text=True, timeout=5).stdout or ""
        for ip in re.findall(r"(?:inet |IPv4[^:]*:\s*)(\d+\.\d+\.\d+\.\d+)", out):
            a, b = int(ip.split(".")[0]), int(ip.split(".")[1])
            if a == 100 and 64 <= b <= 127:
                ts.append(ip)
            elif ip.startswith(("192.168.", "10.")) or (a == 172 and 16 <= b <= 31):
                lan.append(ip)
    except Exception:
        pass
    try:
        s = _s.socket(_s.AF_INET, _s.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        if ip not in lan and not ip.startswith("100."):
            lan.insert(0, ip)
    except Exception:
        pass
    seen_, out_ = set(), []
    for kind, lst in (("tailscale", ts), ("wifi", lan)):
        for ip in lst:
            if ip not in seen_:
                seen_.add(ip)
                out_.append({"kind": kind, "ip": ip,
                             "url": f"http://{ip}:{REMOTE_PORT}/m/{remote_token()}/"})
    return out_


def remote_info():
    if not REMOTE_ENABLED:
        return {"available": False}
    return {"available": True, "on": bool(settings.get("remote_on")), "running": remote_srv is not None,
            "error": remote_err, "port": REMOTE_PORT,
            "addrs": local_addresses() if settings.get("remote_on") else []}


def qr_svg(text):
    try:
        import qrcode
        import qrcode.image.svg
        img = qrcode.make(text, image_factory=qrcode.image.svg.SvgPathImage, box_size=8, border=2)
        import io
        buf = io.BytesIO()
        img.save(buf)
        return buf.getvalue()
    except Exception:
        return None


def _local(method, path, body=None):
    """Forward to the app server (single implementation)"""
    import urllib.request, urllib.error
    data = json.dumps(body or {}).encode() if method == "POST" else None
    req = urllib.request.Request(f"http://127.0.0.1:{PORT}{path}", data=data, method=method,
                                 headers={"X-App": "tlr", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.status, r.read(), r.headers.get("Content-Type", "application/json")
    except urllib.error.HTTPError as e:
        return e.code, e.read(), e.headers.get("Content-Type", "application/json")
    except Exception as e:
        return 502, json.dumps({"error": str(e)}).encode(), "application/json"


def mobile_state():
    s = state_payload()
    keep_j = ("id", "user", "platform", "mode", "state", "recording", "onair", "file", "start_at",
              "next", "pattern", "interval", "end_at", "duration_min")
    keep_d = ("id", "url", "status", "profile", "count", "time", "msg", "files")
    return {"jobs": [{k: j.get(k) for k in keep_j} for j in s["jobs"]],
            "downloads": [{**{k: d.get(k) for k in keep_d}, "files": (d.get("files") or [])[:3]}
                          for d in s["downloads"][:60]],
            "files": s["files"][:8], "version": APP_VERSION}


class RH(BaseHTTPRequestHandler):
    server_version = "SNSCM"

    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        b = body if isinstance(body, bytes) else (body.encode() if isinstance(body, str)
                                                  else json.dumps(body, ensure_ascii=False).encode())
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _auth(self):
        """Only /m/<token>/... is allowed; returns the path after the token"""
        from urllib.parse import urlparse
        import hmac
        u = urlparse(self.path)
        parts = u.path.split("/", 3)          # ['', 'm', token, rest]
        if len(parts) < 3 or parts[1] != "m" or not hmac.compare_digest(parts[2], remote_token()):
            self._send(404, "not found", "text/plain; charset=utf-8")
            return None, None
        return "/" + (parts[3] if len(parts) > 3 else ""), u.query

    def do_GET(self):
        sub, query = self._auth()
        if sub is None:
            return
        from urllib.parse import parse_qs
        if sub == "/" and not self.path.split("?")[0].endswith("/"):
            self.send_response(301)
            self.send_header("Location", self.path.split("?")[0] + "/")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if sub in ("/", "/index.html"):
            html = MOBILE_FILE.read_text(encoding="utf-8").replace("{{VERSION}}", APP_VERSION)
            return self._send(200, html, "text/html; charset=utf-8")
        if sub == "/icon.png":
            return self._send(200, (APP_DIR / "icon.png").read_bytes(), "image/png")
        if sub == "/manifest.json":
            return self._send(200, {"name": "SNS Manager", "short_name": "SNS Manager", "display": "standalone",
                                    "background_color": "#0f0f13", "theme_color": "#0f0f13",
                                    "start_url": "./", "icons": [{"src": "icon.png", "sizes": "512x512",
                                                                  "type": "image/png"}]})
        if sub == "/api/state":
            return self._send(200, mobile_state())
        if sub == "/add":                         # 단축어에서 GET ?url= 로 보내는 경우
            u = parse_qs(query).get("url", [""])[0]
            return self._add(u, want_json=False)
        if sub.startswith(("/avatar/", "/cthumb", "/thumb")):
            code, b, ct = _local("GET", sub + (("?" + query) if query else ""))
            return self._send(code, b, ct)
        self._send(404, "not found", "text/plain; charset=utf-8")

    def _add(self, text, want_json):
        m = _URL_IN_TEXT.search(text or "")
        if not m:
            msg = "No link found. Please share a video, profile or live link."
            if want_json:
                return self._send(400, {"ok": False, "msg": msg})
            return self._send(400, msg, "text/plain; charset=utf-8")
        url = m.group(0).rstrip(".,)")
        kind, err = route(url)
        if err:
            msg = f"⚠️ {err}"
        elif kind == "live":
            msg = "🔴 Live recording started"
        else:
            msg = "⬇️ Download started on your computer"
        if want_json:
            return self._send(200 if not err else 400, {"ok": not err, "msg": msg, "kind": kind})
        return self._send(200 if not err else 400, msg, "text/plain; charset=utf-8")

    def do_POST(self):
        sub, query = self._auth()
        if sub is None:
            return
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(min(n, 200_000)) if n else b""
        ctype = (self.headers.get("Content-Type") or "").lower()
        if sub == "/add":
            text = ""
            if "json" in ctype:
                try:
                    text = str(json.loads(raw or b"{}").get("url", ""))
                except Exception:
                    text = ""
                return self._add(text, want_json=True)
            if "form" in ctype:
                from urllib.parse import parse_qs
                q = parse_qs(raw.decode("utf-8", "replace"))
                text = " ".join(v for vs in q.values() for v in vs)
            else:
                text = raw.decode("utf-8", "replace")
            return self._add(text, want_json=False)
        try:
            body = json.loads(raw or b"{}")
        except Exception:
            body = {}
        parts = sub.strip("/").split("/")
        # 허용하는 조작만 앱 서버로 전달: 녹화 시작·중지, 다운로드 중지·다시·시작
        if len(parts) == 3 and parts[0] == "job" and parts[2] in ("start", "stop"):
            code, b, ct = _local("POST", f"/api/jobs/{parts[1]}/{parts[2]}")
            return self._send(code, b, ct)
        if len(parts) == 3 and parts[0] == "dl" and parts[2] in ("cancel", "retry"):
            code, b, ct = _local("POST", f"/api/dl-{parts[2]}/{parts[1]}")
            return self._send(code, b, ct)
        self._send(404, {"error": "not found"})


def remote_start():
    global remote_srv, remote_err
    if not REMOTE_ENABLED or remote_srv is not None:
        return
    try:
        remote_token()
        srv = ThreadingHTTPServer(("0.0.0.0", REMOTE_PORT), RH)
        remote_srv = srv
        remote_err = ""
        threading.Thread(target=srv.serve_forever, daemon=True).start()
    except Exception as e:
        remote_err = f"Could not open the iPhone connection ({e})"


def remote_stop():
    global remote_srv
    srv, remote_srv = remote_srv, None
    if srv:
        threading.Thread(target=lambda: (srv.shutdown(), srv.server_close()), daemon=True).start()


server = None


restarting = False


def graceful_exit():
    """On update/restart/logout: keep job state, pause, and resume on next start"""
    global restarting
    restarting = True
    for jid, p in list(procs.items()):
        soft_stop(p, jid)                          # 녹화 파일 마무리
    for p in list(dl_procs.values()):
        hard_stop(p)                               # 다운로드는 다음 실행 때 이어서 받음
    deadline = time.time() + 30
    while time.time() < deadline and any(p.poll() is None for p in list(procs.values())):
        time.sleep(0.5)
    for p in list(procs.values()):
        hard_stop(p)
    save(); save_dl()
    os._exit(0)


def shutdown():
    for jid in list(jobs):
        p = procs.get(jid)
        if p and p.poll() is None:
            # 다음 실행 때 다시 켜지도록 상태는 유지하지 않음 (사용자가 종료한 것)
            stop_job(jid, "stopped", wait=False)
    deadline = time.time() + 25
    while time.time() < deadline and any(p.poll() is None for p in procs.values()):
        time.sleep(0.5)
    os._exit(0)


def main():
    global server
    SUP.mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    (SUP / "server.pid").write_text(str(os.getpid()), encoding="utf-8")
    keep_awake()                    # 앱이 켜져 있는 동안 컴퓨터가 잠들지 않게
    if hasattr(signal, "SIGHUP"):
        signal.signal(signal.SIGHUP, signal.SIG_IGN)
    for _d in (DL_OUT,):
        try:
            _d.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    load()
    load_dl()
    threading.Thread(target=lambda: (time.sleep(25), load_history()), daemon=True).start()   # NAS 확인 후 기록 채우기
    threading.Thread(target=ensure_tools, daemon=True).start()
    threading.Thread(target=updater_loop, daemon=True).start()
    try:
        st = SUP / ".all-updated"
        if st.exists():
            upd["last"] = datetime.fromtimestamp(st.stat().st_mtime).strftime("%m/%d %H:%M")
    except Exception:
        pass
    threading.Thread(target=monitor, daemon=True).start()
    threading.Thread(target=live_checker, daemon=True).start()
    threading.Thread(target=dl_worker, daemon=True).start()
    threading.Thread(target=clip_watcher, daemon=True).start()
    threading.Thread(target=nas_sync, daemon=True).start()
    threading.Thread(target=avatar_filler, daemon=True).start()
    if REMOTE_ENABLED and settings.get("remote_on"):
        remote_start()
    signal.signal(signal.SIGTERM, lambda *a: threading.Thread(target=graceful_exit, daemon=True).start())
    server.serve_forever()


if __name__ == "__main__":
    main()
