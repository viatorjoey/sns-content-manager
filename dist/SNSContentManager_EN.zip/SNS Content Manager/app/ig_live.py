#!/usr/bin/env python3
"""Instagram live recorder (SNS Content Manager)

Same usage as the TikTok recorder:
  ig_live.py -user NAME -mode automatic|manual [-automatic_interval MIN] -output DIR
  ig_live.py -user NAME --check      → prints live status as one JSON line

Uses the login saved by the app's Instagram login (cookies/instagram.txt).
"""
import argparse
import http.cookiejar
import os
import json
import shutil
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

APP_ID = "936619743392459"   # 인스타그램 웹 앱 ID (웹사이트가 쓰는 공개 값)
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/130.0 Safari/537.36")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import stopwatch  # noqa: E402

IS_WIN = sys.platform.startswith("win")


def data_dir():
    if os.environ.get("SNSCM_DATA"):
        return Path(os.environ["SNSCM_DATA"])
    if IS_WIN:
        return Path(os.environ.get("LOCALAPPDATA", Path.home())) / "SNSContentManager"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "SNSContentManager"
    return Path.home() / ".local" / "share" / "SNSContentManager"


COOKIES = data_dir() / "data" / "cookies" / "instagram.txt"


def log(*a):
    print(*a, flush=True)


class IG:
    def __init__(self):
        self.jar = http.cookiejar.MozillaCookieJar()
        try:
            self.jar.load(str(COOKIES), ignore_discard=True, ignore_expires=True)
        except Exception:
            raise RuntimeError("Not logged in to Instagram — use 🔑 Instagram login in the app")
        if not any(c.name == "sessionid" and "instagram" in c.domain for c in self.jar):
            raise RuntimeError("Not logged in to Instagram — use 🔑 Instagram login in the app")
        self.op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))
        self.csrf = next((c.value for c in self.jar if c.name == "csrftoken" and "instagram" in c.domain), "")

    def get(self, url):
        req = urllib.request.Request(url, headers={
            "User-Agent": UA, "X-IG-App-ID": APP_ID, "X-CSRFToken": self.csrf,
            "X-Requested-With": "XMLHttpRequest", "Referer": "https://www.instagram.com/", "Accept": "*/*"})
        with self.op.open(req, timeout=15) as r:
            return json.loads(r.read().decode("utf-8", "replace") or "{}")

    def user(self, name):
        d = self.get(f"https://www.instagram.com/api/v1/users/web_profile_info/?username={name}")
        u = ((d.get("data") or {}).get("user")) or {}
        if not u.get("id"):
            raise RuntimeError(f"@{name} Account not found")
        return u["id"], (u.get("profile_pic_url_hd") or u.get("profile_pic_url") or "")

    def live(self, uid):
        """If live {'url','viewers','title'}, else None"""
        try:
            d = self.get(f"https://www.instagram.com/api/v1/live/web_info/?target_user_id={uid}")
        except urllib.error.HTTPError as e:
            if e.code in (400, 404):
                return None
            raise
        for obj in (d, d.get("broadcast") or {}, d.get("data") or {}):
            url = obj.get("dash_abr_playback_url") or obj.get("dash_playback_url") or obj.get("dash_live_predictive_playback_url")
            if url:
                st = obj.get("broadcast_status")
                if st not in (None, "active"):
                    return None
                return {"url": url, "viewers": obj.get("viewer_count") or 0,
                        "title": obj.get("broadcast_message") or ""}
        return None


def ffmpeg_bin():
    for c in (data_dir() / "bin" / ("ffmpeg.exe" if IS_WIN else "ffmpeg"),):
        if c.exists():
            return str(c)
    return shutil.which("ffmpeg") or "ffmpeg"


def record(info, user, out: Path):
    out.mkdir(parents=True, exist_ok=True)
    fn = out / f"IG_{user}_{datetime.now():%Y%m%d_%H%M%S}.mp4"
    log(f"[*] Recording @{user} → {fn.name}")
    # 조각난 mp4 → 중간에 끊겨도 그때까지 녹화분은 재생 가능
    p = subprocess.Popen([ffmpeg_bin(), "-hide_banner", "-loglevel", "warning", "-user_agent", UA,
                          "-i", info["url"], "-c", "copy",
                          "-movflags", "+frag_keyframe+empty_moov+default_base_moof", str(fn)],
                         stdin=subprocess.PIPE)
    try:
        rc = p.wait()
    except KeyboardInterrupt:          # 앱에서 '중지' → ffmpeg 에 'q'(정상 종료)를 보내 파일 마무리
        try:
            p.stdin.write(b"q"); p.stdin.flush()
        except Exception:
            pass
        try:
            p.wait(timeout=20)
        except Exception:
            p.terminate()
        raise
    log(f"[*] Recording finished (ffmpeg exit {rc})")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-user", required=True)
    ap.add_argument("-mode", default="manual")
    ap.add_argument("-automatic_interval", type=int, default=5)
    ap.add_argument("-output", default=".")
    ap.add_argument("-no-update-check", action="store_true")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    user = a.user.lstrip("@")

    if a.check:
        try:
            ig = IG()
            uid, pic = ig.user(user)
            lv = ig.live(uid)
            print(json.dumps({"live": bool(lv), "viewers": (lv or {}).get("viewers", 0),
                              "title": (lv or {}).get("title", ""), "avatar": pic}))
        except Exception as e:
            print(json.dumps({"live": None, "error": str(e)[:200]}))
        return 0

    out = Path(a.output)
    try:
        ig = IG()
        uid, _ = ig.user(user)
        log(f"[*] @{user} (id {uid}) watching started · mode {a.mode}")
        while True:
            try:
                lv = ig.live(uid)
            except Exception as e:
                log(f"[!] Check failed: {e}")
                lv = None
            if lv:
                record(lv, user, out)
                if a.mode != "automatic":
                    return 0
                time.sleep(10)
                continue
            if a.mode != "automatic":
                log(f"[!] @{user} is not live")
                return 1
            log(f"[*] @{user} is offline · {a.automatic_interval}min until next check")
            time.sleep(max(1, a.automatic_interval) * 60)
    except KeyboardInterrupt:
        log("[*] stopped by user")
        return 0
    except Exception as e:
        log(f"[ERROR] {e}")
        return 1


if __name__ == "__main__":
    stopwatch.install()
    sys.exit(main())
