#!/bin/bash
# SNS 채널 컨텐츠 매니저 — Mac 제거 (받아 둔 영상·사진 파일은 지우지 않음)
APPNAME="SNS Content Manager"
LABEL="com.snscm.server"
DATA="$HOME/Library/Application Support/SNSContentManager"
UIDN=$(id -u)

echo "Uninstall $APPNAME? Your downloaded videos, photos and recordings are kept. [y/N]"
read -r ans
[[ "$ans" =~ ^[Yy]$ ]] || { echo "Cancelled."; exit 0; }

curl -s -m 3 -X POST -H 'X-App: tlr' http://127.0.0.1:8777/api/restart >/dev/null 2>&1 || true
sleep 3
launchctl bootout "gui/$UIDN/$LABEL" 2>/dev/null || true
rm -f "$HOME/Library/LaunchAgents/$LABEL.plist"
pkill -f "SNSContentManager/app/" 2>/dev/null || true
mv "$HOME/Applications/$APPNAME.app" "$HOME/.Trash/$APPNAME.app.$(date +%s)" 2>/dev/null || true

echo "Also delete app data (recording list, download history, logins)? [y/N]"
read -r ans2
if [[ "$ans2" =~ ^[Yy]$ ]]; then
  rm -rf "$DATA"
  echo "App data deleted."
else
  rm -rf "$DATA/env" "$DATA/app" "$DATA/recorder" "$DATA/bin" "$DATA/webview"
  echo "Lists, history and settings were kept (reused if you reinstall): $DATA/data"
fi
echo "Uninstall complete."
