﻿# SNS 채널 컨텐츠 매니저 — Windows 제거 (받아 둔 영상·사진 파일은 지우지 않음)
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$AppName = 'SNS Content Manager'
$Data    = Join-Path $env:LOCALAPPDATA 'SNSContentManager'

$a = Read-Host "Uninstall $AppName? Your downloaded videos, photos and recordings are kept. (y/N)"
if ($a -notmatch '^[Yy]$') { Write-Host 'Cancelled.'; Start-Sleep 2; exit 0 }

try { Invoke-WebRequest -Method Post -Uri 'http://127.0.0.1:8777/api/restart' -Headers @{ 'X-App' = 'tlr' } -Body '{}' -UseBasicParsing -TimeoutSec 3 | Out-Null; Start-Sleep 5 } catch {}
Get-CimInstance Win32_Process -Filter "Name like 'python%'" | Where-Object { $_.CommandLine -like '*SNSContentManager*' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Start-Sleep 1

Remove-Item (Join-Path ([Environment]::GetFolderPath('Desktop')) "$AppName.lnk") -Force
Remove-Item (Join-Path ([Environment]::GetFolderPath('Programs')) $AppName) -Recurse -Force
Remove-Item (Join-Path ([Environment]::GetFolderPath('Startup')) "$AppName (background).lnk") -Force
Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\SNSContentManager' -Recurse -Force

$b = Read-Host 'Also delete app data (recording list, download history, logins)? (y/N)'
if ($b -match '^[Yy]$') {
  Set-Location $env:TEMP
  Remove-Item $Data -Recurse -Force
  Write-Host 'App data deleted.'
} else {
  foreach ($d in 'env', 'app', 'recorder', 'bin', 'webview') { Remove-Item (Join-Path $Data $d) -Recurse -Force }
  Write-Host "Lists, history and settings were kept (reused if you reinstall): $Data\data"
}
Write-Host 'Uninstall complete.'
Start-Sleep 3
