﻿# ─────────────────────────────────────────────────────────────
#  SNS 채널 컨텐츠 매니저 — Windows 10/11 설치
#  필요한 것: 인터넷 연결. 관리자 권한 필요 없음 (내 사용자 계정에만 설치).
# ─────────────────────────────────────────────────────────────
$ErrorActionPreference = 'Continue'   # do not treat progress output as errors (exit codes are checked)
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$AppName = 'SNS Content Manager'
$Pkg     = Split-Path -Parent $PSScriptRoot
$Data    = Join-Path $env:LOCALAPPDATA 'SNSContentManager'
$Py      = Join-Path $Data 'env\Scripts\python.exe'
$Pyw     = Join-Path $Data 'env\Scripts\pythonw.exe'
New-Item -ItemType Directory -Force -Path "$Data\logs", "$Data\bin", "$Data\data" | Out-Null
Start-Transcript -Path "$Data\logs\install.log" -Append | Out-Null

function Step($m) { Write-Host "`n▶ $m" -ForegroundColor Cyan }
function Fail($m) {
  Write-Host "`n✖ $m" -ForegroundColor Red
  Write-Host "Install log: $Data\logs\install.log"
  Stop-Transcript | Out-Null
  Read-Host "Press Enter to close"
  exit 1
}

Write-Host "════════ Installing $AppName ════════"

# 1) uv (파이썬·패키지 설치 도구)
Step 'Preparing installer tool (uv)'
$Uv = Join-Path $env:USERPROFILE '.local\bin\uv.exe'
if (-not (Test-Path $Uv)) {
  $c = Get-Command uv -ErrorAction SilentlyContinue
  if ($c) { $Uv = $c.Source } else {
    try { Invoke-RestMethod https://astral.sh/uv/install.ps1 | Invoke-Expression } catch { Fail "uv install failed (check internet connection): $_" }
    if (-not (Test-Path $Uv)) { $c = Get-Command uv -ErrorAction SilentlyContinue; if ($c) { $Uv = $c.Source } }
  }
}
if (-not (Test-Path $Uv)) { Fail 'uv not found' }

# 2) Edge WebView2 (앱 창 표시용 — 윈도우 11 은 기본 설치됨)
Step 'Checking app window component (WebView2)'
$wv = @(
  'HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
  'HKLM:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
  'HKCU:\Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'
) | Where-Object { Test-Path $_ }
if (-not $wv) {
  Write-Host '  Installing WebView2…'
  $boot = Join-Path $env:TEMP 'MicrosoftEdgeWebview2Setup.exe'
  try {
    Invoke-WebRequest 'https://go.microsoft.com/fwlink/p/?LinkId=2124703' -OutFile $boot -UseBasicParsing
    Start-Process $boot -ArgumentList '/silent', '/install' -Wait
  } catch { Write-Host "  Skipped WebView2 install: $_" -ForegroundColor Yellow }
}

# 3) 실행 중인 이전 버전 정리 (진행 중인 녹화 파일은 안전하게 마무리)
Step 'Cleaning up previous version'
try { Invoke-WebRequest -Method Post -Uri 'http://127.0.0.1:8777/api/restart' -Headers @{ 'X-App' = 'tlr' } -Body '{}' -UseBasicParsing -TimeoutSec 3 | Out-Null; Start-Sleep 5 } catch {}
Get-CimInstance Win32_Process -Filter "Name like 'python%'" | Where-Object { $_.CommandLine -like '*SNSContentManager*' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep 1

# 4) 앱 파일 복사
Step 'Copying app files'
if (Test-Path "$Data\app") { Remove-Item "$Data\app" -Recurse -Force }
Copy-Item "$Pkg\app" "$Data\app" -Recurse -Force -ErrorAction Stop
Copy-Item "$Pkg\installer\uninstall_windows.ps1" "$Data\app\uninstall_windows.ps1" -Force
Get-ChildItem "$Data\app" -Recurse | Unblock-File -ErrorAction SilentlyContinue

# 5) 파이썬 환경 + 필요한 프로그램
Step 'Creating Python 3.12 environment'
& $Uv python install 3.12; if ($LASTEXITCODE) { Fail 'Python install failed' }
if (-not (Test-Path $Py)) { & $Uv venv "$Data\env" --python 3.12; if ($LASTEXITCODE) { Fail 'Creating Python environment failed' } }
Step 'Installing components (yt-dlp · gallery-dl · ffmpeg · app window) — takes a few minutes'
& $Uv pip install -p $Py -U -r "$Data\app\requirements.txt"; if ($LASTEXITCODE) { Fail 'Installing components failed' }

# 6) 틱톡 라이브 녹화기
Step 'Installing TikTok live recorder'
$tmp = Join-Path $env:TEMP ("snscm_" + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
try {
  Invoke-WebRequest 'https://github.com/Michele0303/tiktok-live-recorder/archive/refs/heads/main.zip' -OutFile "$tmp\rec.zip" -UseBasicParsing
  Expand-Archive "$tmp\rec.zip" -DestinationPath $tmp -Force
} catch { Fail "Recorder download failed: $_" }
$src = Get-ChildItem $tmp -Directory | Where-Object { $_.Name -like 'tiktok-live-recorder-*' } | Select-Object -First 1
foreach ($f in 'cookies.json', 'telegram.json') {
  if (Test-Path "$Data\recorder\src\$f") { Copy-Item "$Data\recorder\src\$f" "$($src.FullName)\src\$f" -Force }
}
if (Test-Path "$Data\recorder") { Remove-Item "$Data\recorder" -Recurse -Force }
Move-Item $src.FullName "$Data\recorder"
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
& $Uv pip install -p $Py -r "$Data\recorder\pyproject.toml"; if ($LASTEXITCODE) { Fail 'Recorder components install failed' }

# 7) ffmpeg
Step 'Preparing ffmpeg'
& $Py -c "import imageio_ffmpeg,shutil,os; d=os.path.join(os.environ['LOCALAPPDATA'],'SNSContentManager','bin'); os.makedirs(d,exist_ok=True); shutil.copy2(imageio_ffmpeg.get_ffmpeg_exe(), os.path.join(d,'ffmpeg.exe')); print('  ffmpeg ok')"
if ($LASTEXITCODE) { Fail 'Preparing ffmpeg failed' }

# 8) 바로가기 (바탕화면 · 시작 메뉴) + 로그인할 때 백그라운드 자동 시작
Step 'Creating shortcuts'
$sh = New-Object -ComObject WScript.Shell
function New-Lnk($path, $target, $arguments, $desc) {
  $l = $sh.CreateShortcut($path)
  $l.TargetPath = $target; $l.Arguments = $arguments; $l.WorkingDirectory = $Data
  $l.IconLocation = "$Data\app\icon.ico,0"; $l.Description = $desc
  $l.Save()
}
$desk  = [Environment]::GetFolderPath('Desktop')
$menu  = Join-Path ([Environment]::GetFolderPath('Programs')) $AppName
$start = [Environment]::GetFolderPath('Startup')
New-Item -ItemType Directory -Force -Path $menu | Out-Null
New-Lnk "$desk\$AppName.lnk" $Pyw "`"$Data\app\launcher.py`"" $AppName
New-Lnk "$menu\$AppName.lnk" $Pyw "`"$Data\app\launcher.py`"" $AppName
New-Lnk "$menu\Uninstall $AppName.lnk" 'powershell.exe' "-NoProfile -ExecutionPolicy Bypass -File `"$Data\app\uninstall_windows.ps1`"" "Uninstall $AppName"
New-Lnk "$start\$AppName (background).lnk" $Pyw "`"$Data\app\server.py`"" "$AppName background recording and downloads"

# 9) 설정 > 앱 목록에 등록 (여기서도 제거 가능)
$u = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\SNSContentManager'
New-Item -Path $u -Force | Out-Null
Set-ItemProperty $u DisplayName $AppName
Set-ItemProperty $u DisplayVersion (Get-Content "$Data\app\VERSION")
Set-ItemProperty $u DisplayIcon "$Data\app\icon.ico"
Set-ItemProperty $u Publisher 'SNS Channel Content Manager'
Set-ItemProperty $u InstallLocation $Data
Set-ItemProperty $u UninstallString "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$Data\app\uninstall_windows.ps1`""
Set-ItemProperty $u NoModify 1 -Type DWord
Set-ItemProperty $u NoRepair 1 -Type DWord

# 10) 시작
Step 'Starting background service · opening the app'
Start-Process $Pyw -ArgumentList "`"$Data\app\server.py`"" -WorkingDirectory $Data -WindowStyle Hidden
for ($i = 0; $i -lt 40; $i++) {
  try { Invoke-WebRequest 'http://127.0.0.1:8777/api/ping' -UseBasicParsing -TimeoutSec 2 | Out-Null; break } catch { Start-Sleep -Milliseconds 500 }
}
Start-Process $Pyw -ArgumentList "`"$Data\app\launcher.py`"" -WorkingDirectory $Data

Write-Host "`n✔ Installed!" -ForegroundColor Green
Write-Host "  · Open it from the '$AppName' icon on the Desktop or Start menu."
Write-Host "  · Recording and downloads continue in the background after you close the window (starts automatically with the computer)."
Stop-Transcript | Out-Null
Start-Sleep 4
